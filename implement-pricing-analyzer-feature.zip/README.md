# Kartik Clarity™ — Pricing Analyzer™

Forensic pricing diagnostic built on Next.js (App Router), TypeScript, Tailwind CSS v4,
and PostgreSQL via Drizzle ORM.

Pricing Analyzer™ evaluates eleven linked pricing stages —
**Value → Buyer → Offer → Packaging → Price Metric → Price Level → Discounting →
Conversion → Expansion → Retention → Margin** — from 33 evidence-based questions,
then produces:

- a **deterministic composite score** (fixed rules applied to your answers, never model-generated),
- a **confidence rating reported separately** from the score, based on evidence strength,
- **heuristic revenue-leakage exposure ranges** (not fabricated financial figures), and
- a **prioritized, evidence-linked action plan** that distinguishes pricing-*system*
  problems from simple price-*level* problems.

## Stack

- Next.js 16 (App Router, TypeScript, Turbopack)
- Tailwind CSS v4 (`@theme` tokens derived from the Kartik Clarity™ brand marks)
- Drizzle ORM + PostgreSQL (`pg` driver)

## Getting started

```bash
cp .env.example .env   # point DATABASE_URL at your local Postgres
npm install
npx drizzle-kit push   # create the pricing_assessments table
npm run dev
```

App runs at `http://localhost:3000`. Health check: `GET /api/health`.

## Project layout

```
src/app/                          Routes (home, Pricing Analyzer wizard, report, API)
src/components/site/              Header/Footer with brand lockups
src/components/pricing-analyzer/  Wizard UI + report exhibit components
src/lib/pricing-analyzer/         Questions, forensic flag library, deterministic engine
src/db/                           Drizzle schema + client
public/brand/                     Kartik Clarity™ circle & rectangle logo lockups (JPEG)
```

## Diagnostic engine

All scoring logic lives in `src/lib/pricing-analyzer/engine.ts` and is pure,
deterministic TypeScript — the same answers always produce the same score. Findings
("flags") are authored in `src/lib/pricing-analyzer/flags.ts`; nothing is generated
by a model at request time, so nothing can be fabricated.

## Production build

```bash
npm run build
npm run start
```
