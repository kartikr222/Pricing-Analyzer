import { randomUUID } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { pricingAssessments } from "@/db/schema";
import { runDiagnostic } from "./engine";
import type { Answers, DiagnosticReport, IntakeContext } from "./types";

export async function createAssessment(context: IntakeContext, answers: Answers) {
  const report = runDiagnostic(context, answers);
  const id = randomUUID();

  await db.insert(pricingAssessments).values({
    id,
    organization: context.organization ?? null,
    contactEmail: context.contactEmail ?? null,
    businessModel: context.businessModel,
    annualRevenue: context.annualRevenue ?? null,
    currency: context.currency,
    answers,
    report,
    compositeScore: report.compositeScore,
    confidenceLevel: report.confidence.level,
  });

  return { id, report };
}

export async function getAssessment(id: string): Promise<DiagnosticReport | null> {
  const rows = await db
    .select()
    .from(pricingAssessments)
    .where(eq(pricingAssessments.id, id))
    .limit(1);

  const row = rows[0];
  if (!row) return null;
  return row.report as DiagnosticReport;
}
