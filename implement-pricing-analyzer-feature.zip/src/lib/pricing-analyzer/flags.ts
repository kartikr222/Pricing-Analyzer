import type { FlagDefinition } from "./types";

// Every flag below is a static, human-authored forensic pattern definition.
// The engine only ever *selects* flags that the respondent's own answers
// triggered — it never invents a finding, a leakage figure, or an action.
export const FLAGS: Record<string, FlagDefinition> = {
  // ───────────────────────── VALUE ─────────────────────────
  "value.anecdotal-only": {
    id: "value.anecdotal-only", stage: "value", class: "system", severity: "medium",
    finding: "Value is argued through anecdote and case study rather than a repeatable, quantified proof point — every rep is effectively re-deriving the business case from scratch.",
    action: { title: "Codify a quantified value/ROI model sales can reuse deal-to-deal", rationale: "A single, defensible ROI construct shortens the value conversation and removes reliance on individual rep storytelling skill.", effort: "medium" },
  },
  "value.no-quant": {
    id: "value.no-quant", stage: "value", class: "system", severity: "high",
    finding: "No quantified outcome or ROI figure exists for a typical customer — pricing conversations have nothing to anchor against except the buyer's own budget ceiling.",
    leakage: { lowPct: 4, highPct: 9, note: "of gross bookings is plausibly conceded in negotiation when there is no quantified value anchor to negotiate against." },
    action: { title: "Build a baseline value-quantification model before touching price", rationale: "Price changes made without a value anchor tend to be argued on cost or competitor grounds, which caps upside and invites discounting.", effort: "high" },
  },
  "value.visibility-gap": {
    id: "value.visibility-gap", stage: "value", class: "system", severity: "low",
    finding: "Ownership of the value narrative could not be confirmed — this stage is currently a measurement blind spot rather than a known-good or known-bad state.",
    action: { title: "Assign explicit ownership of the value narrative (product marketing or RevOps)", rationale: "Undiagnosed stages cannot be improved deliberately; ownership converts a blind spot into a tracked metric.", effort: "low" },
  },
  "value.feature-led": {
    id: "value.feature-led", stage: "value", class: "level", severity: "medium",
    finding: "Sales conversations open on capability rather than quantified outcome, which frames price as a cost to be minimized instead of a return to be justified.",
    action: { title: "Re-sequence the sales narrative: outcome first, capability second, price third", rationale: "Sequencing — not new collateral — is usually the fastest fix, since the proof points already exist.", effort: "low" },
  },
  "value.price-led": {
    id: "value.price-led", stage: "value", class: "system", severity: "high",
    finding: "Price is typically the first substantive topic in the sales conversation, which trains buyers to evaluate the offer as a commodity before any value case is made.",
    leakage: { lowPct: 3, highPct: 7, note: "of gross bookings is a reasonable estimate of value conceded when price is discussed before value is established." },
    action: { title: "Delay pricing disclosure until a value/outcome case has been made", rationale: "This is a process discipline fix, not a pricing fix — it is typically the highest-leverage, lowest-cost change available.", effort: "low" },
  },
  "value.inconsistent-narrative": {
    id: "value.inconsistent-narrative", stage: "value", class: "system", severity: "medium",
    finding: "The value narrative varies materially by rep, which means pricing outcomes are a function of individual skill rather than a repeatable system.",
    action: { title: "Standardize the value narrative into a single reusable script/deck", rationale: "Removes rep-to-rep variance in win rate and discount depth that has nothing to do with the deal itself.", effort: "medium" },
  },
  "value.stale-narrative": {
    id: "value.stale-narrative", stage: "value", class: "level", severity: "medium",
    finding: "The value proof points predate the current product — the narrative may be underselling capability the product has since gained.",
    action: { title: "Refresh ROI proof points against the current product surface", rationale: "Products that have shipped meaningful value since the last narrative refresh are commonly underpriced relative to what they now deliver.", effort: "medium" },
  },
  "value.never-validated": {
    id: "value.never-validated", stage: "value", class: "system", severity: "high",
    finding: "The value case has never been formally validated with customers — it is an internal assumption, not evidence.",
    leakage: { lowPct: 4, highPct: 8, note: "of gross bookings is a reasonable exposure estimate when the value case has no customer-side validation to defend it." },
    action: { title: "Run structured willingness-to-pay / value-validation interviews", rationale: "Unvalidated value claims collapse under buyer pushback; validated ones hold and reduce discount pressure.", effort: "high" },
  },

  // ───────────────────────── BUYER ─────────────────────────
  "buyer.inconsistent-id": {
    id: "buyer.inconsistent-id", stage: "buyer", class: "system", severity: "medium",
    finding: "Economic buyer identification happens informally rather than as a required qualification step, creating late-stage surprises.",
    action: { title: "Add economic-buyer confirmation as a formal stage-gate in the sales process", rationale: "A one-line qualification requirement removes the most common source of late-cycle stalls.", effort: "low" },
  },
  "buyer.blind-to-buyer": {
    id: "buyer.blind-to-buyer", stage: "buyer", class: "system", severity: "high",
    finding: "The true budget owner is rarely identified before late in the deal, meaning most of the sales cycle is spent building a case with someone who cannot approve it.",
    leakage: { lowPct: 3, highPct: 6, note: "of pipeline value is reasonably at risk of stalling or re-negotiation once the actual budget owner is finally engaged." },
    action: { title: "Require economic-buyer engagement before proposal stage", rationale: "Deals negotiated without the budget owner in the room are renegotiated once that person appears — usually downward.", effort: "medium" },
  },
  "buyer.visibility-gap": {
    id: "buyer.visibility-gap", stage: "buyer", class: "system", severity: "low",
    finding: "Buyer-side dynamics (budget ownership, approval thresholds, loss reasons) are not consistently tracked.",
    action: { title: "Add buyer-role and loss-reason fields to CRM as required, not optional, fields", rationale: "This stage cannot be diagnosed further until the underlying data exists.", effort: "low" },
  },
  "buyer.reactive-thresholds": {
    id: "buyer.reactive-thresholds", stage: "buyer", class: "level", severity: "medium",
    finding: "Procurement and approval thresholds are learned mid-deal rather than anticipated, which forces reactive concessions to keep deals moving.",
    action: { title: "Document known approval thresholds by segment and brief reps proactively", rationale: "Anticipating thresholds lets deals be structured (timing, scope) to avoid them, rather than discounted through them.", effort: "medium" },
  },
  "buyer.threshold-blindness": {
    id: "buyer.threshold-blindness", stage: "buyer", class: "system", severity: "high",
    finding: "Budget and approval thresholds are consistently discovered late, which is a structural — not situational — sales process gap.",
    leakage: { lowPct: 3, highPct: 6, note: "of gross bookings is plausibly lost to concessions made to clear approval surprises discovered late in the cycle." },
    action: { title: "Build a threshold-mapping step into deal qualification", rationale: "This converts a recurring emergency into a known, plannable step earlier in the cycle.", effort: "medium" },
  },
  "buyer.no-decision-losses": {
    id: "buyer.no-decision-losses", stage: "buyer", class: "system", severity: "high",
    finding: "\"No decision\" is a leading loss reason — this typically signals the buyer was never truly qualified as ready and able to act, not that price was too high.",
    action: { title: "Tighten qualification criteria on buying intent and timeline before investing sales cycles", rationale: "No-decision losses are frequently misdiagnosed as pricing problems when they are actually qualification problems.", effort: "medium" },
  },
  "buyer.no-budget-losses": {
    id: "buyer.no-budget-losses", stage: "buyer", class: "system", severity: "high",
    finding: "Deals are commonly lost to \"no budget\" after significant sales investment, indicating budget is confirmed too late to be a qualifying criterion.",
    action: { title: "Move budget confirmation earlier in the qualification sequence", rationale: "Confirming budget exists before investing a full sales cycle protects both pipeline efficiency and sales capacity.", effort: "low" },
  },

  // ───────────────────────── OFFER ─────────────────────────
  "offer.uninformed-tiers": {
    id: "offer.uninformed-tiers", stage: "offer", class: "system", severity: "medium",
    finding: "Tier structure was adopted from a competitor or convention rather than derived from this business's own willingness-to-pay segments.",
    action: { title: "Re-derive tier boundaries from your own customer segmentation data", rationale: "Borrowed structures rarely match your actual buyer distribution and tend to under-monetize the highest-value segment.", effort: "high" },
  },
  "offer.single-sku": {
    id: "offer.single-sku", stage: "offer", class: "level", severity: "medium",
    finding: "A single flat offer serves all buyer segments, leaving no mechanism to capture more value from high-willingness-to-pay customers or win price-sensitive ones with a lighter tier.",
    action: { title: "Introduce at least a two-tier structure to segment willingness-to-pay", rationale: "Segmentation via packaging is typically the single highest-leverage lever for capturing latent willingness-to-pay.", effort: "high" },
  },
  "offer.ad-hoc-structuring": {
    id: "offer.ad-hoc-structuring", stage: "offer", class: "system", severity: "high",
    finding: "The offer is re-negotiated bespoke on nearly every deal, which removes any standard reference point for what \"the deal\" should look like.",
    leakage: { lowPct: 5, highPct: 10, note: "of gross bookings is a reasonable exposure estimate when every deal is custom-structured with no standard reference point." },
    action: { title: "Publish a standard offer architecture reps must justify deviating from", rationale: "A default structure converts every negotiation from a blank page into a defensible exception process.", effort: "medium" },
  },
  "offer.unintentional-anchor": {
    id: "offer.unintentional-anchor", stage: "offer", class: "level", severity: "low",
    finding: "A top tier exists but was not deliberately designed to reframe the target tier as reasonable — its anchoring effect, if any, is accidental.",
    action: { title: "Redesign the top tier explicitly as a decoy/anchor", rationale: "A deliberately engineered anchor tier reliably shifts purchase behavior toward the target tier at negligible cost.", effort: "low" },
  },
  "offer.no-anchor": {
    id: "offer.no-anchor", stage: "offer", class: "level", severity: "medium",
    finding: "No premium anchor tier exists, so the mid or entry tier is evaluated against the buyer's own budget rather than against a higher internal reference point.",
    action: { title: "Add a premium anchor tier above your target tier", rationale: "Anchoring is one of the best-evidenced, lowest-cost levers in pricing psychology and is currently unused.", effort: "medium" },
  },
  "offer.opportunistic-attach": {
    id: "offer.opportunistic-attach", stage: "offer", class: "system", severity: "medium",
    finding: "Add-on and upsell attach happens opportunistically per rep rather than through a defined motion, leaving attach revenue dependent on individual initiative.",
    action: { title: "Build a defined attach motion into the standard sales playbook", rationale: "Converting an opportunistic behavior into a required step is usually a fast, low-cost revenue lift.", effort: "medium" },
  },
  "offer.no-attach-motion": {
    id: "offer.no-attach-motion", stage: "offer", class: "level", severity: "medium",
    finding: "Little to no revenue is captured from add-ons or upsell at point of sale, leaving a monetization layer entirely untapped.",
    action: { title: "Identify 2-3 high-fit add-ons and introduce them at point of sale", rationale: "Point-of-sale attach is typically easier to capture than post-sale expansion since buying intent is already active.", effort: "medium" },
  },

  // ───────────────────────── PACKAGING ─────────────────────────
  "packaging.engineering-led-gating": {
    id: "packaging.engineering-led-gating", stage: "packaging", class: "system", severity: "high",
    finding: "Feature-to-tier assignment follows engineering or roadmap convenience rather than validated customer segments, so packaging does not track value.",
    leakage: { lowPct: 3, highPct: 7, note: "of ARR is a reasonable exposure estimate when packaging does not align to customer value segments." },
    action: { title: "Re-map tier gating to willingness-to-pay segments, not build order", rationale: "Packaging is a monetization decision, not an engineering sequencing decision — treating it as the latter systematically undercharges advanced segments.", effort: "high" },
  },
  "packaging.arbitrary-gating": {
    id: "packaging.arbitrary-gating", stage: "packaging", class: "system", severity: "high",
    finding: "Nobody can currently explain the logic behind which features sit in which tier — packaging has drifted into an unmanaged, historical artifact.",
    action: { title: "Run a packaging audit and re-justify every tier boundary from first principles", rationale: "Unowned packaging tends to both leave value on the table and generate customer confusion — the audit typically pays for itself.", effort: "high" },
  },
  "packaging.visibility-gap": {
    id: "packaging.visibility-gap", stage: "packaging", class: "system", severity: "low",
    finding: "Packaging has apparently never been reviewed against data, and nobody could confirm its current rationale.",
    action: { title: "Schedule a first structured packaging review", rationale: "You cannot optimize what has never been examined; this establishes the baseline.", effort: "low" },
  },
  "packaging.aging": {
    id: "packaging.aging", stage: "packaging", class: "level", severity: "medium",
    finding: "Packaging was last data-tested 12-24 months ago — plausibly stale relative to how the product and customer base have evolved since.",
    action: { title: "Re-run a packaging test using current usage and segment data", rationale: "Products evolve faster than packaging typically gets revisited; a refresh is likely overdue.", effort: "medium" },
  },
  "packaging.stale-packaging": {
    id: "packaging.stale-packaging", stage: "packaging", class: "system", severity: "high",
    finding: "Packaging has not been tested or restructured in over two years, or ever — a strong signal it no longer matches customer value perception.",
    leakage: { lowPct: 3, highPct: 6, note: "of ARR is a reasonable exposure estimate for packaging that has gone materially stale relative to product evolution." },
    action: { title: "Commission a full packaging redesign informed by current usage data", rationale: "Multi-year-stale packaging is one of the more reliable predictors of latent monetization upside.", effort: "high" },
  },
  "packaging.explainability-friction": {
    id: "packaging.explainability-friction", stage: "packaging", class: "system", severity: "medium",
    finding: "Sales regularly has to clarify tier contents mid-deal, which slows cycles and signals the packaging is not self-evidently understandable.",
    action: { title: "Simplify tier naming and feature grouping for at-a-glance clarity", rationale: "Packaging that requires explanation adds friction and cycle time to every single deal.", effort: "medium" },
  },
  "packaging.chronic-confusion": {
    id: "packaging.chronic-confusion", stage: "packaging", class: "system", severity: "high",
    finding: "Packaging confusion shows up chronically in support and renewal conversations — a sign it is actively damaging trust and retention, not just sales efficiency.",
    leakage: { lowPct: 2, highPct: 5, note: "of ARR is a reasonable exposure estimate for retention risk driven by chronic packaging confusion." },
    action: { title: "Simplify packaging and add a plain-language comparison view", rationale: "Confusion that surfaces at renewal is a retention risk, not just a sales inconvenience — it merits urgent simplification.", effort: "high" },
  },

  // ───────────────────────── PRICE METRIC ─────────────────────────
  "metric.partial-misalignment": {
    id: "metric.partial-misalignment", stage: "priceMetric", class: "level", severity: "medium",
    finding: "The pricing metric is misaligned with value for at least one identifiable customer segment, even if it works for the average customer.",
    action: { title: "Introduce a segment-specific metric variant or cap for the affected segment", rationale: "A targeted fix for the mismatched segment avoids a full metric overhaul while closing the specific leak.", effort: "medium" },
  },
  "metric.misaligned": {
    id: "metric.misaligned", stage: "priceMetric", class: "system", severity: "high",
    finding: "The price metric does not scale with the value received — in some cases it may actively penalize customer growth or usage, which caps expansion revenue by design.",
    leakage: { lowPct: 4, highPct: 9, note: "of ARR is a reasonable exposure estimate when the billing metric is structurally disconnected from delivered value." },
    action: { title: "Redesign the price metric to scale with a value-correlated unit", rationale: "This is a structural fix with compounding payoff: a value-aligned metric grows revenue automatically as customers succeed.", effort: "high" },
  },
  "metric.visibility-gap": {
    id: "metric.visibility-gap", stage: "priceMetric", class: "system", severity: "low",
    finding: "Alignment between the price metric and delivered value has never been formally assessed.",
    action: { title: "Run a metric-alignment review across your top customer segments", rationale: "This establishes whether the current metric is a hidden constraint before further pricing work is done.", effort: "medium" },
  },
  "metric.segment-friction": {
    id: "metric.segment-friction", stage: "priceMetric", class: "system", severity: "medium",
    finding: "One or more segments regularly generate objections or disputes tied specifically to how usage is metered or billed.",
    action: { title: "Investigate and resolve the specific metric friction point for the affected segment", rationale: "Segment-specific billing friction is a solvable, bounded problem and is worth resolving before it becomes a churn driver.", effort: "medium" },
  },
  "metric.chronic-disputes": {
    id: "metric.chronic-disputes", stage: "priceMetric", class: "system", severity: "high",
    finding: "Billing metric disputes are a recurring, chronic pattern — this is a structural design issue with the metric itself, not an education problem.",
    leakage: { lowPct: 2, highPct: 5, note: "of ARR is a reasonable churn-risk exposure estimate tied to chronic billing disputes." },
    action: { title: "Redesign the metering/billing construct causing recurring disputes", rationale: "Chronic disputes are a leading indicator of churn; they are cheaper to fix at the metric level than to manage one account at a time.", effort: "high" },
  },
  "metric.aging-review": {
    id: "metric.aging-review", stage: "priceMetric", class: "level", severity: "low",
    finding: "The pricing metric was reviewed once but not since, despite likely product and market evolution.",
    action: { title: "Put metric review on a recurring (annual) governance cadence", rationale: "A one-time review goes stale; a cadence keeps the metric current with the business.", effort: "low" },
  },
  "metric.unexamined": {
    id: "metric.unexamined", stage: "priceMetric", class: "system", severity: "medium",
    finding: "The price metric is the one chosen at founding and has never been deliberately reconsidered as the business model matured.",
    action: { title: "Formally evaluate whether the founding-era metric still fits the current business", rationale: "Metrics chosen pre-product-market-fit are frequently a poor fit for the business the company has become.", effort: "medium" },
  },

  // ───────────────────────── PRICE LEVEL ─────────────────────────
  "level.competitor-anchored": {
    id: "level.competitor-anchored", stage: "priceLevel", class: "level", severity: "medium",
    finding: "Price level follows competitor benchmarking rather than this business's own quantified value — it inherits competitors' pricing mistakes as well as their logic.",
    action: { title: "Validate price level against your own value model, not competitor list prices", rationale: "Competitor-anchored pricing caps upside at whatever the least-informed competitor charges.", effort: "medium" },
  },
  "level.cost-plus": {
    id: "level.cost-plus", stage: "priceLevel", class: "level", severity: "medium",
    finding: "Price is set from a cost-plus or margin-target formula, which is disconnected from what the customer's outcome is actually worth.",
    action: { title: "Layer a value-based check on top of the cost-plus floor", rationale: "Cost-plus protects margin but structurally caps price at cost economics rather than customer value — value-based pricing typically raises the ceiling.", effort: "high" },
  },
  "level.gut-set": {
    id: "level.gut-set", stage: "priceLevel", class: "system", severity: "high",
    finding: "Price level was set by judgment and has never been methodically tested — there is no evidence base behind the current number.",
    leakage: { lowPct: 4, highPct: 10, note: "of ARR is a reasonable exposure estimate for a price level with no supporting evidence base." },
    action: { title: "Commission a structured price-level study (van Westendorp, conjoint, or comparable)", rationale: "Untested gut pricing is one of the highest-variance risks in the whole system — it is equally likely to be leaving money on the table or overexposed to competition.", effort: "high" },
  },
  "level.aging-price": {
    id: "level.aging-price", stage: "priceLevel", class: "level", severity: "low",
    finding: "List price has not moved in one to two years, a period in which delivered value has plausibly increased.",
    action: { title: "Schedule the next price review now rather than waiting for a trigger event", rationale: "Regular, planned increases are easier for the market to absorb than large, reactive ones.", effort: "low" },
  },
  "level.stale-price": {
    id: "level.stale-price", stage: "priceLevel", class: "level", severity: "high",
    finding: "List price has been static for more than two years while the product has continued to evolve — a strong candidate for being underpriced relative to current value.",
    leakage: { lowPct: 5, highPct: 12, note: "of ARR is a reasonable exposure estimate for a price level that has not moved in over two years of product evolution." },
    action: { title: "Execute a deliberate price increase with existing-customer grandfathering rules", rationale: "Multi-year price staleness is one of the most reliably underpriced conditions we see — this is typically the single highest-ROI lever available.", effort: "medium" },
  },
  "level.never-raised": {
    id: "level.never-raised", stage: "priceLevel", class: "level", severity: "high",
    finding: "Price has never been raised since launch — every dollar of subsequent value delivered has been given away by default.",
    leakage: { lowPct: 6, highPct: 14, note: "of ARR is a reasonable exposure estimate for a price that has never once been increased." },
    action: { title: "Plan and execute the first structured price increase", rationale: "A first increase is often the largest single lever available and should be sequenced ahead of smaller optimizations.", effort: "medium" },
  },
  "level.marginal-list-viability": {
    id: "level.marginal-list-viability", stage: "priceLevel", class: "mixed", severity: "medium",
    finding: "Full-price deals close only about half the time — list price is marginally viable, sitting close to the edge of what the market bears without a discount.",
    action: { title: "Test a modest list-price reduction or a lower-friction entry tier alongside a repricing study", rationale: "A 50/50 full-price close rate needs a controlled test to determine whether the fix is price level or sales conviction, not a guess.", effort: "medium" },
  },
  "level.list-price-not-viable": {
    id: "level.list-price-not-viable", stage: "priceLevel", class: "mixed", severity: "high",
    finding: "Full-price deals rarely close without a discount — list price is functionally fictional and the real transacted price is set ad hoc in negotiation.",
    leakage: { lowPct: 5, highPct: 11, note: "of gross bookings is a reasonable exposure estimate when list price is not a credible reference point in most deals." },
    action: { title: "Reset list price to reflect the real transacted price, then re-introduce discipline from there", rationale: "A list price nobody pays trains both sales and buyers to treat every deal as fully negotiable — resetting it restores a credible anchor.", effort: "high" },
  },
  "level.visibility-gap": {
    id: "level.visibility-gap", stage: "priceLevel", class: "system", severity: "low",
    finding: "Full-price win rate is not tracked separately from discounted win rate, so the true viability of list price is unknown.",
    action: { title: "Segment win-rate reporting by discounted vs. full-price deals", rationale: "This single reporting change unlocks visibility into whether the price level itself is the constraint.", effort: "low" },
  },

  // ───────────────────────── DISCOUNTING ─────────────────────────
  "disc.unenforced-policy": {
    id: "disc.unenforced-policy", stage: "discounting", class: "system", severity: "high",
    finding: "A discount approval policy exists on paper but is routinely bypassed in practice — the control is cosmetic, not operative.",
    leakage: { lowPct: 4, highPct: 9, note: "of gross bookings is a reasonable exposure estimate for governance that exists on paper but is not enforced." },
    action: { title: "Enforce existing discount approval thresholds through CRM workflow, not policy memo", rationale: "Policies that rely on voluntary compliance are reliably bypassed under quota pressure — enforcement needs to be systemic.", effort: "medium" },
  },
  "disc.no-governance": {
    id: "disc.no-governance", stage: "discounting", class: "system", severity: "high",
    finding: "No formal discount approval process exists — discounting authority is fully discretionary at the individual rep level.",
    leakage: { lowPct: 5, highPct: 11, note: "of gross bookings is a reasonable exposure estimate for fully discretionary, ungoverned discounting." },
    action: { title: "Establish tiered discount approval thresholds tied to deal size and depth", rationale: "This is typically the single fastest-to-implement, highest-ROI control in the entire pricing system.", effort: "low" },
  },
  "disc.visibility-gap": {
    id: "disc.visibility-gap", stage: "discounting", class: "system", severity: "medium",
    finding: "How discounting is actually approved could not be confirmed — the control environment is unknown, which is itself a governance risk.",
    action: { title: "Document and audit the actual (not assumed) discount approval path", rationale: "You cannot govern a control you cannot describe; this audit is the necessary first step.", effort: "low" },
  },
  "disc.moderate-depth": {
    id: "disc.moderate-depth", stage: "discounting", class: "level", severity: "low",
    finding: "Average discount depth (11-20%) is within a normal range but still represents a meaningful, recurring value transfer to buyers.",
    action: { title: "Tighten the top of the discount band by 3-5 points via approval friction", rationale: "Small, low-drama reductions in typical discount depth compound meaningfully across full-year bookings.", effort: "low" },
  },
  "disc.deep-average": {
    id: "disc.deep-average", stage: "discounting", class: "mixed", severity: "high",
    finding: "Average discount depth (21-35%) is deep enough to suggest either list price is set too high for the market, or governance is too weak to hold the line — likely both.",
    leakage: { lowPct: 6, highPct: 12, note: "of gross bookings is a reasonable exposure estimate at this discount depth relative to a disciplined benchmark." },
    action: { title: "Run a combined price-level and governance review before adjusting either alone", rationale: "Discount depth this high is rarely explained by one cause — fixing governance without checking price level (or vice versa) leaves half the leak open.", effort: "high" },
  },
  "disc.severe-depth": {
    id: "disc.severe-depth", stage: "discounting", class: "mixed", severity: "high",
    finding: "Average discount depth exceeds 35% — at this level, list price and transacted price have effectively decoupled.",
    leakage: { lowPct: 9, highPct: 18, note: "of gross bookings is a reasonable exposure estimate at this severity of average discounting." },
    action: { title: "Treat this as a full pricing-system incident: freeze further discount creep and re-baseline list price", rationale: "At this depth, incremental fixes are unlikely to hold; a full reset of the reference price is usually required.", effort: "high" },
  },
  "disc.frequent": {
    id: "disc.frequent", stage: "discounting", class: "level", severity: "low",
    finding: "25-50% of deals include some discount — discounting is common but not yet the default behavior.",
    action: { title: "Introduce a lightweight justification requirement for any discount", rationale: "A small amount of friction at the point of discounting reliably reduces frequency without harming win rate.", effort: "low" },
  },
  "disc.majority-discounted": {
    id: "disc.majority-discounted", stage: "discounting", class: "system", severity: "medium",
    finding: "A majority (50-80%) of deals close with a discount, meaning list price functions as a starting offer rather than a real price.",
    leakage: { lowPct: 5, highPct: 10, note: "of gross bookings is a reasonable exposure estimate when discounting has become the majority behavior." },
    action: { title: "Introduce a defined, limited set of standard discount scenarios (e.g., term, volume) and disallow ad hoc ones", rationale: "Constraining discounting to a short list of pre-approved scenarios preserves flexibility while removing open-ended negotiation.", effort: "medium" },
  },
  "disc.default-discounting": {
    id: "disc.default-discounting", stage: "discounting", class: "system", severity: "high",
    finding: "Over 80% of deals include a discount — discounting is effectively the default sale mechanism, and list price carries no real signal.",
    leakage: { lowPct: 8, highPct: 16, note: "of gross bookings is a reasonable exposure estimate when discounting has become the default deal mechanism." },
    action: { title: "Re-baseline list price to the effective market price, then reintroduce governed discounting from a credible floor", rationale: "When discounting is universal, the honest fix is to reset the reference price rather than continue policing an already-fictional one.", effort: "high" },
  },

  // ───────────────────────── CONVERSION ─────────────────────────
  "conv.midrange-winrate": {
    id: "conv.midrange-winrate", stage: "conversion", class: "level", severity: "low",
    finding: "A 25-40% proposal-to-close win rate is workable but leaves room to test whether packaging, price, or sales execution is the binding constraint.",
    action: { title: "Run win/loss interviews on the next 10 closed-lost deals", rationale: "Direct buyer feedback will indicate whether the constraint is price, fit, or process before you spend on any one fix.", effort: "low" },
  },
  "conv.low-winrate": {
    id: "conv.low-winrate", stage: "conversion", class: "system", severity: "medium",
    finding: "A 10-25% proposal-to-close win rate suggests a structural conversion problem — most fully-qualified proposals are failing to close.",
    action: { title: "Audit the proposal stage for qualification quality and pricing presentation", rationale: "Low win rate at the proposal stage specifically (not top-of-funnel) usually points to either weak qualification earlier or an unconvincing offer presentation.", effort: "medium" },
  },
  "conv.very-low-winrate": {
    id: "conv.very-low-winrate", stage: "conversion", class: "system", severity: "high",
    finding: "A sub-10% proposal-to-close win rate is a severe conversion failure that likely touches qualification, offer design, and pricing presentation simultaneously.",
    leakage: { lowPct: 3, highPct: 7, note: "of pipeline value is a reasonable estimate of sales capacity wasted pursuing proposals that were never likely to close." },
    action: { title: "Freeze proposal volume and run a root-cause review before scaling outbound further", rationale: "Scaling a broken conversion motion multiplies wasted sales capacity rather than revenue.", effort: "high" },
  },
  "conv.visibility-gap": {
    id: "conv.visibility-gap", stage: "conversion", class: "system", severity: "medium",
    finding: "Proposal-to-close win rate is not tracked, which means conversion health cannot currently be distinguished from top-of-funnel volume effects.",
    action: { title: "Instrument proposal-to-close win rate as a standalone CRM metric", rationale: "This single metric is foundational to distinguishing a pipeline problem from a conversion problem.", effort: "low" },
  },
  "conv.lengthening-cycle": {
    id: "conv.lengthening-cycle", stage: "conversion", class: "mixed", severity: "medium",
    finding: "Sales cycles are moderately lengthening, a leading indicator worth monitoring before it becomes a chronic conversion drag.",
    action: { title: "Identify the specific stage where cycle time is growing", rationale: "Early detection at the stage level is far cheaper to fix than a company-wide cycle-time initiative later.", effort: "low" },
  },
  "conv.stalling-cycle": {
    id: "conv.stalling-cycle", stage: "conversion", class: "system", severity: "high",
    finding: "Sales cycles are lengthening significantly with repeated stalls — this is consistent with either a qualification failure or a pricing/offer friction point recurring across deals.",
    action: { title: "Map the stall point across your last 20 stalled deals", rationale: "A pattern across many deals at the same stage reveals a systemic fix rather than twenty individual ones.", effort: "medium" },
  },
  "conv.procurement-friction": {
    id: "conv.procurement-friction", stage: "conversion", class: "level", severity: "medium",
    finding: "Procurement/legal process, not price, is the dominant stall reason — this is a process problem being misattributed to pricing if left undiagnosed.",
    action: { title: "Pre-package procurement requirements (security review, MSA terms) before they become blockers", rationale: "Procurement friction is usually solvable with preparation, and is frequently confused with pricing resistance.", effort: "medium" },
  },
  "conv.price-objection-stalls": {
    id: "conv.price-objection-stalls", stage: "conversion", class: "mixed", severity: "high",
    finding: "Unresolved price/budget objections are the leading stall reason — this implicates either price level, value communication, or both.",
    leakage: { lowPct: 3, highPct: 7, note: "of pipeline value is a reasonable estimate of deals stalling specifically on unresolved price objections." },
    action: { title: "Build a structured objection-handling framework tied back to the value case, not just discounting", rationale: "The reflex response to a price objection is a discount; a value-based rebuttal path resolves more objections without conceding price.", effort: "medium" },
  },

  // ───────────────────────── EXPANSION ─────────────────────────
  "exp.flat-expansion": {
    id: "exp.flat-expansion", stage: "expansion", class: "level", severity: "low",
    finding: "Net revenue retention (100-110%) is roughly flat — the existing base is neither a strong growth engine nor a drag.",
    action: { title: "Identify your top 20% highest-usage accounts as expansion test candidates", rationale: "Flat NRR usually hides a subset of accounts ready to expand that simply haven't been approached.", effort: "medium" },
  },
  "exp.net-contraction": {
    id: "exp.net-contraction", stage: "expansion", class: "mixed", severity: "high",
    finding: "Net revenue retention (90-100%) shows the existing base is contracting net of any expansion — new logos are compensating for base erosion.",
    leakage: { lowPct: 4, highPct: 9, note: "of ARR is a reasonable exposure estimate for a customer base in mild net contraction." },
    action: { title: "Run a base-health audit segmented by account tenure and usage trend", rationale: "Net contraction blends churn and expansion signals — segmenting reveals which is the primary driver before you fix the wrong one.", effort: "medium" },
  },
  "exp.severe-contraction": {
    id: "exp.severe-contraction", stage: "expansion", class: "mixed", severity: "high",
    finding: "Net revenue retention below 90% indicates the existing customer base is a material drag on growth, independent of new logo acquisition.",
    leakage: { lowPct: 8, highPct: 16, note: "of ARR is a reasonable exposure estimate for a customer base in severe net contraction." },
    action: { title: "Prioritize a base-retention and expansion program above new-logo acquisition", rationale: "Below 90% NRR, growth math is fighting the base rather than being helped by it — this is usually the more urgent fix.", effort: "high" },
  },
  "exp.visibility-gap": {
    id: "exp.visibility-gap", stage: "expansion", class: "system", severity: "high",
    finding: "Net revenue retention is not tracked — this is a critical blind spot, since it is one of the single best indicators of pricing-system health.",
    action: { title: "Instrument net revenue retention as a standing board-level metric", rationale: "NRR is foundational to diagnosing pricing health; without it, expansion and retention issues are effectively invisible.", effort: "low" },
  },
  "exp.ad-hoc-motion": {
    id: "exp.ad-hoc-motion", stage: "expansion", class: "system", severity: "high",
    finding: "Expansion happens only when a rep happens to notice an opportunity — there is no systematized trigger or ownership for growing existing accounts.",
    leakage: { lowPct: 3, highPct: 7, note: "of ARR is a reasonable exposure estimate for expansion revenue left uncaptured without a systematic motion." },
    action: { title: "Define usage/seat-growth triggers that automatically flag expansion opportunities", rationale: "Systematizing expansion typically surfaces revenue that already exists in usage data but is never acted upon.", effort: "medium" },
  },
  "exp.no-motion": {
    id: "exp.no-motion", stage: "expansion", class: "system", severity: "high",
    finding: "No structured expansion path exists at all — growth is entirely dependent on new-logo acquisition.",
    leakage: { lowPct: 4, highPct: 9, note: "of ARR is a reasonable exposure estimate for the absence of any structured expansion motion." },
    action: { title: "Design and own a formal expansion motion (usage tiers, seat growth, module upsell)", rationale: "Expansion revenue is typically cheaper to capture than new-logo revenue and is currently entirely unaddressed.", effort: "high" },
  },
  "exp.limited-expansion": {
    id: "exp.limited-expansion", stage: "expansion", class: "level", severity: "low",
    finding: "10-30% of accounts expanded in the last year — a functioning but likely under-resourced expansion motion.",
    action: { title: "Increase account coverage for expansion outreach among usage-qualified accounts", rationale: "A working motion applied to more of the eligible base is a low-risk way to grow expansion revenue.", effort: "medium" },
  },
  "exp.stagnant-base": {
    id: "exp.stagnant-base", stage: "expansion", class: "system", severity: "medium",
    finding: "Under 10% of accounts expanded in the last year — the base is largely stagnant even where usage growth may exist.",
    action: { title: "Cross-reference usage growth against spend growth to find uncaptured expansion", rationale: "Accounts whose usage is growing faster than their spend are the most immediate expansion opportunity available.", effort: "medium" },
  },

  // ───────────────────────── RETENTION ─────────────────────────
  "ret.discretionary-renewals": {
    id: "ret.discretionary-renewals", stage: "retention", class: "system", severity: "medium",
    finding: "Renewal pricing is decided case-by-case rather than systematically, creating inconsistent economics and unpredictable revenue.",
    action: { title: "Establish a default renewal uplift policy with a defined exception process", rationale: "A default reduces both revenue leakage and the negotiation burden on the account team at every renewal.", effort: "medium" },
  },
  "ret.flat-renewals": {
    id: "ret.flat-renewals", stage: "retention", class: "level", severity: "medium",
    finding: "Customers renew at flat pricing by default, meaning any value delivered since the last renewal is never captured in price.",
    leakage: { lowPct: 2, highPct: 5, note: "of ARR is a reasonable exposure estimate for a flat-renewal-by-default policy over a multi-year customer lifetime." },
    action: { title: "Introduce a modest, standard annual renewal uplift", rationale: "Even a small systematic uplift compounds meaningfully across the base and is easier to introduce than a one-time large increase later.", effort: "low" },
  },
  "ret.renewal-erosion": {
    id: "ret.renewal-erosion", stage: "retention", class: "mixed", severity: "high",
    finding: "Renewals are sometimes priced below the prior term to avoid churn — this actively erodes the revenue base and signals price is being used reactively to manage churn risk rather than proactively.",
    leakage: { lowPct: 5, highPct: 11, note: "of ARR is a reasonable exposure estimate for renewal pricing that erodes below prior-term value." },
    action: { title: "Separate churn-risk management from renewal pricing — address risk with success intervention, not discounting", rationale: "Using price as a retention tool trains the base to expect discounts at renewal, compounding the erosion each cycle.", effort: "high" },
  },
  "ret.moderate-churn": {
    id: "ret.moderate-churn", stage: "retention", class: "level", severity: "low",
    finding: "Gross churn (5-10%) is within a defensible range but still represents a meaningful annual revenue base to defend.",
    action: { title: "Segment churn by cohort to find the specific driver worth addressing first", rationale: "Even moderate churn usually concentrates in identifiable segments that are more efficient to address than the whole base.", effort: "medium" },
  },
  "ret.elevated-churn": {
    id: "ret.elevated-churn", stage: "retention", class: "mixed", severity: "high",
    finding: "Gross churn (10-20%) is elevated enough to materially offset new bookings and warrants root-cause investigation.",
    leakage: { lowPct: 4, highPct: 9, note: "of ARR is a reasonable exposure estimate for churn at this elevated level." },
    action: { title: "Run root-cause analysis on the last two quarters of churned accounts", rationale: "At this churn level, understanding whether the driver is price, value, or product fit determines which fix actually works.", effort: "medium" },
  },
  "ret.severe-churn": {
    id: "ret.severe-churn", stage: "retention", class: "mixed", severity: "high",
    finding: "Gross churn above 20% is severe and likely dominates the growth equation regardless of new bookings performance.",
    leakage: { lowPct: 10, highPct: 20, note: "of ARR is a reasonable exposure estimate for churn at this severe level." },
    action: { title: "Treat churn as the top company priority above acquisition until root cause is addressed", rationale: "At this severity, no amount of new-logo growth can outrun the base erosion.", effort: "high" },
  },
  "ret.visibility-gap": {
    id: "ret.visibility-gap", stage: "retention", class: "system", severity: "high",
    finding: "Churn rate is not tracked, which is a critical blind spot for any recurring-revenue business.",
    action: { title: "Instrument gross and net churn as standing metrics immediately", rationale: "This is a foundational metric — no retention diagnosis is possible without it.", effort: "low" },
  },
  "ret.some-discounted-renewals": {
    id: "ret.some-discounted-renewals", stage: "retention", class: "level", severity: "low",
    finding: "10-30% of renewals happen at a discount to full value — a manageable but non-trivial share of the base.",
    action: { title: "Review discounted renewals for a common root cause (segment, tenure, or account owner)", rationale: "A small consistent pattern is usually cheaper to fix than the discounting itself.", effort: "low" },
  },
  "ret.majority-discounted-renewals": {
    id: "ret.majority-discounted-renewals", stage: "retention", class: "system", severity: "medium",
    finding: "30-60% of renewals occur at a discount — discounted renewal is becoming a normalized expectation rather than an exception.",
    leakage: { lowPct: 3, highPct: 7, note: "of ARR is a reasonable exposure estimate when a substantial share of renewals transact below full value." },
    action: { title: "Introduce a renewal pricing governance process mirroring new-deal discount controls", rationale: "Renewals are frequently under-governed relative to new deals despite representing a larger share of revenue over time.", effort: "medium" },
  },
  "ret.chronic-discounted-renewals": {
    id: "ret.chronic-discounted-renewals", stage: "retention", class: "system", severity: "high",
    finding: "Over 60% of renewals occur at a discount — full-value renewal is now the exception rather than the rule.",
    leakage: { lowPct: 6, highPct: 13, note: "of ARR is a reasonable exposure estimate when the large majority of renewals transact below full value." },
    action: { title: "Reset renewal pricing baseline and apply new-deal-grade governance to renewals", rationale: "At this frequency, discounted renewal has become the de facto price — the reference point itself needs resetting.", effort: "high" },
  },

  // ───────────────────────── MARGIN ─────────────────────────
  "margin.eroding": {
    id: "margin.eroding", stage: "margin", class: "level", severity: "medium",
    finding: "Gross margin is slightly declining, a trend worth arresting before it compounds.",
    action: { title: "Identify whether margin erosion tracks to discounting, delivery cost, or mix shift", rationale: "The fix differs materially depending on which of the three is the actual driver.", effort: "medium" },
  },
  "margin.material-erosion": {
    id: "margin.material-erosion", stage: "margin", class: "mixed", severity: "high",
    finding: "Gross margin is materially declining, which — combined with other signals in this report — likely reflects discounting and/or pricing-metric issues rather than cost alone.",
    leakage: { lowPct: 4, highPct: 9, note: "of ARR is a reasonable exposure estimate implied by material, ongoing gross margin erosion." },
    action: { title: "Run a deal-level margin decomposition across the last two quarters", rationale: "Aggregate margin trends hide whether the driver is a handful of severely discounted deals or a broad-based shift — decomposition tells you which.", effort: "high" },
  },
  "margin.visibility-gap": {
    id: "margin.visibility-gap", stage: "margin", class: "system", severity: "high",
    finding: "Margin is not tracked at the product or deal level, meaning pricing decisions are made without visibility into their true economic impact.",
    action: { title: "Instrument deal-level margin reporting alongside bookings reporting", rationale: "Bookings without margin visibility is an incomplete picture that can mask serious economic erosion.", effort: "medium" },
  },
  "margin.misaligned-incentives": {
    id: "margin.misaligned-incentives", stage: "margin", class: "system", severity: "high",
    finding: "Sales compensation rewards revenue regardless of discount given, making discounting effectively free from the rep's perspective.",
    leakage: { lowPct: 4, highPct: 9, note: "of gross bookings is a reasonable exposure estimate when compensation does not penalize margin-eroding discounts." },
    action: { title: "Re-weight sales compensation toward net price or margin-adjusted bookings", rationale: "Incentive design is frequently the true root cause of a chronic discounting problem — it typically outperforms policy-only fixes.", effort: "high" },
  },
  "margin.inconsistent-incentives": {
    id: "margin.inconsistent-incentives", stage: "margin", class: "system", severity: "medium",
    finding: "Compensation treatment of discounting is inconsistent across teams, creating uneven discounting behavior for reasons unrelated to the deal itself.",
    action: { title: "Standardize margin-aware compensation treatment across all sales teams", rationale: "Inconsistency itself is often the problem — teams with weaker margin incentives will reliably discount more.", effort: "medium" },
  },
  "margin.list-only-tracking": {
    id: "margin.list-only-tracking", stage: "margin", class: "system", severity: "high",
    finding: "Discounts are tracked only as a percentage off list, with no visibility into the resulting margin impact deal-by-deal.",
    leakage: { lowPct: 3, highPct: 7, note: "of ARR is a reasonable exposure estimate for margin erosion that goes unmeasured under list-only discount tracking." },
    action: { title: "Add margin-impact fields to discount approval and reporting workflows", rationale: "A discount that looks small as a percentage of list can be large as a percentage of margin — this gap hides real exposure.", effort: "medium" },
  },
  "margin.no-tracking": {
    id: "margin.no-tracking", stage: "margin", class: "system", severity: "high",
    finding: "Discounts are not tracked against margin in any structured way — the true cost of discounting to the business is currently unknown.",
    leakage: { lowPct: 4, highPct: 8, note: "of ARR is a reasonable exposure estimate for margin erosion that is currently entirely unmeasured." },
    action: { title: "Stand up baseline discount-to-margin tracking before making further pricing changes", rationale: "This is foundational visibility — without it, every other pricing decision is being made partially blind.", effort: "medium" },
  },
};
