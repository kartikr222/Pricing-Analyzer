import type { Question, StageId } from "./types";

export const STAGES: { id: StageId; label: string; weight: number; description: string }[] = [
  { id: "value", label: "Value", weight: 10, description: "Is delivered value articulated and quantified before price is discussed?" },
  { id: "buyer", label: "Buyer", weight: 8, description: "Is the true economic buyer and their approval path understood?" },
  { id: "offer", label: "Offer", weight: 8, description: "Is what's being sold structured to segment willingness-to-pay?" },
  { id: "packaging", label: "Packaging", weight: 9, description: "Are features mapped to tiers deliberately, not arbitrarily?" },
  { id: "priceMetric", label: "Price Metric", weight: 9, description: "Does what you charge for scale with the value received?" },
  { id: "priceLevel", label: "Price Level", weight: 11, description: "Is the price point itself evidence-based and current?" },
  { id: "discounting", label: "Discounting", weight: 12, description: "Is discounting governed, or discretionary?" },
  { id: "conversion", label: "Conversion", weight: 8, description: "Do qualified proposals actually close?" },
  { id: "expansion", label: "Expansion", weight: 8, description: "Does the existing base grow spend systematically?" },
  { id: "retention", label: "Retention", weight: 9, description: "Is renewal pricing disciplined, and is churn understood?" },
  { id: "margin", label: "Margin", weight: 8, description: "Does the organization see and protect deal-level economics?" },
];

export const QUESTIONS: Question[] = [
  // VALUE
  {
    id: "value.quant", stage: "value",
    prompt: "Can your team quantify, in numbers, the return or outcome a typical customer gets from your product or service?",
    options: [
      { value: "a", label: "Yes — customer-validated ROI/outcome data is used in sales and pricing conversations", points: 90, evidence: "strong" },
      { value: "b", label: "Yes, but it's anecdotal or case-study based, not rigorously measured", points: 55, evidence: "moderate", flagIds: ["value.anecdotal-only"] },
      { value: "c", label: "No — value is described qualitatively and never quantified", points: 20, evidence: "strong", flagIds: ["value.no-quant"] },
      { value: "d", label: "Not sure how sales currently positions this", points: 50, evidence: "unknown", flagIds: ["value.visibility-gap"] },
    ],
  },
  {
    id: "value.leads", stage: "value",
    prompt: "In a typical sales conversation, what leads: quantified value, or price?",
    options: [
      { value: "a", label: "We anchor on quantified value/outcomes first; price follows once value is established", points: 90, evidence: "strong" },
      { value: "b", label: "We lead with features/capabilities; price comes up early without a quantified case", points: 55, evidence: "moderate", flagIds: ["value.feature-led"] },
      { value: "c", label: "Price is usually the first substantive topic raised", points: 25, evidence: "strong", flagIds: ["value.price-led"] },
      { value: "d", label: "Varies significantly by rep, with no consistent approach", points: 40, evidence: "moderate", flagIds: ["value.inconsistent-narrative"] },
    ],
  },
  {
    id: "value.refresh", stage: "value",
    prompt: "Has your value narrative or ROI proof been re-validated in the last 12 months as the product changed?",
    options: [
      { value: "a", label: "Yes, refreshed at least annually", points: 85, evidence: "strong" },
      { value: "b", label: "It has been more than 12 months since it was last revisited", points: 45, evidence: "strong", flagIds: ["value.stale-narrative"] },
      { value: "c", label: "It has never been formally validated with customers", points: 20, evidence: "strong", flagIds: ["value.never-validated"] },
      { value: "d", label: "Not sure / not clearly owned by anyone", points: 50, evidence: "unknown", flagIds: ["value.visibility-gap"] },
    ],
  },

  // BUYER
  {
    id: "buyer.economic", stage: "buyer",
    prompt: "Do you consistently know who the true economic buyer (budget owner) is, versus the champion or user?",
    options: [
      { value: "a", label: "Yes, consistently identified and engaged separately from the champion", points: 90, evidence: "strong" },
      { value: "b", label: "Usually, but it isn't systematically confirmed", points: 55, evidence: "moderate", flagIds: ["buyer.inconsistent-id"] },
      { value: "c", label: "Rarely — deals often stall or surprise us at the approval stage", points: 25, evidence: "strong", flagIds: ["buyer.blind-to-buyer"] },
      { value: "d", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["buyer.visibility-gap"] },
    ],
  },
  {
    id: "buyer.approval", stage: "buyer",
    prompt: "Do you understand the buyer's approval thresholds (what triggers procurement, legal, or multi-level sign-off)?",
    options: [
      { value: "a", label: "Yes, and we structure timing and scope to stay ahead of those thresholds", points: 88, evidence: "strong" },
      { value: "b", label: "Partially — thresholds are usually discovered reactively, mid-deal", points: 55, evidence: "moderate", flagIds: ["buyer.reactive-thresholds"] },
      { value: "c", label: "No — thresholds regularly surprise us late in the cycle", points: 25, evidence: "strong", flagIds: ["buyer.threshold-blindness"] },
      { value: "d", label: "Not sure", points: 50, evidence: "unknown", flagIds: ["buyer.visibility-gap"] },
    ],
  },
  {
    id: "buyer.lossreason", stage: "buyer",
    prompt: "When deals are lost, what's the most common recorded reason?",
    options: [
      { value: "a", label: "Lost to a competitor on clear, well-understood criteria", points: 75, evidence: "strong" },
      { value: "b", label: "Lost to \"no decision\" — the prospect went silent", points: 40, evidence: "strong", flagIds: ["buyer.no-decision-losses"] },
      { value: "c", label: "Lost to \"no budget\" after significant sales investment", points: 35, evidence: "strong", flagIds: ["buyer.no-budget-losses"] },
      { value: "d", label: "We don't consistently track loss reasons", points: 45, evidence: "unknown", flagIds: ["buyer.visibility-gap"] },
    ],
  },

  // OFFER
  {
    id: "offer.structure", stage: "offer",
    prompt: "How is your core offer structured today?",
    options: [
      { value: "a", label: "Clear tiered structure (e.g., Good/Better/Best) with a deliberate anchor tier", points: 88, evidence: "strong" },
      { value: "b", label: "Tiers exist but were copied from a competitor or set without willingness-to-pay research", points: 55, evidence: "moderate", flagIds: ["offer.uninformed-tiers"] },
      { value: "c", label: "Single, flat offer for all customer segments", points: 40, evidence: "strong", flagIds: ["offer.single-sku"] },
      { value: "d", label: "Offer structure is renegotiated bespoke on nearly every deal", points: 30, evidence: "strong", flagIds: ["offer.ad-hoc-structuring"] },
    ],
  },
  {
    id: "offer.anchor", stage: "offer",
    prompt: "Is there a deliberate premium tier most customers aren't expected to buy, used to make the target tier look reasonable?",
    options: [
      { value: "a", label: "Yes, and it measurably shifts customers toward the target tier", points: 85, evidence: "strong" },
      { value: "b", label: "A top tier exists but wasn't designed as an anchor", points: 55, evidence: "moderate", flagIds: ["offer.unintentional-anchor"] },
      { value: "c", label: "No anchor tier exists", points: 35, evidence: "strong", flagIds: ["offer.no-anchor"] },
      { value: "d", label: "Not sure how customers perceive our tiers", points: 50, evidence: "unknown", flagIds: ["offer.visibility-gap"] },
    ],
  },
  {
    id: "offer.attach", stage: "offer",
    prompt: "What share of point-of-sale revenue comes from add-ons, modules, or upsell (beyond the base package)?",
    options: [
      { value: "a", label: "Meaningful attach (over 20%), with a defined attach motion", points: 85, evidence: "strong" },
      { value: "b", label: "Some attach (5-20%), mostly opportunistic and rep-driven", points: 55, evidence: "moderate", flagIds: ["offer.opportunistic-attach"] },
      { value: "c", label: "Little to no attach revenue", points: 30, evidence: "strong", flagIds: ["offer.no-attach-motion"] },
      { value: "d", label: "We don't break this out", points: 45, evidence: "unknown", flagIds: ["offer.visibility-gap"] },
    ],
  },

  // PACKAGING
  {
    id: "packaging.gating", stage: "packaging",
    prompt: "How are features assigned to tiers or packages?",
    options: [
      { value: "a", label: "Deliberately gated by validated willingness-to-pay segments", points: 88, evidence: "strong" },
      { value: "b", label: "Gated mostly by engineering or roadmap convenience, not customer segments", points: 45, evidence: "strong", flagIds: ["packaging.engineering-led-gating"] },
      { value: "c", label: "Arbitrary or historical — nobody recalls the original logic", points: 30, evidence: "strong", flagIds: ["packaging.arbitrary-gating"] },
      { value: "d", label: "Not sure — it's never been reviewed", points: 50, evidence: "unknown", flagIds: ["packaging.visibility-gap"] },
    ],
  },
  {
    id: "packaging.tested", stage: "packaging",
    prompt: "When was packaging (what's included in each tier) last tested or restructured using customer or usage data?",
    options: [
      { value: "a", label: "Within the last 12 months, data-informed", points: 85, evidence: "strong" },
      { value: "b", label: "12-24 months ago", points: 55, evidence: "moderate", flagIds: ["packaging.aging"] },
      { value: "c", label: "More than 2 years ago, or never", points: 30, evidence: "strong", flagIds: ["packaging.stale-packaging"] },
      { value: "d", label: "Not sure", points: 50, evidence: "unknown", flagIds: ["packaging.visibility-gap"] },
    ],
  },
  {
    id: "packaging.confusion", stage: "packaging",
    prompt: "How often do prospects or customers express confusion about what's included in each tier?",
    options: [
      { value: "a", label: "Rarely — packaging is understood in a single explanation", points: 85, evidence: "strong" },
      { value: "b", label: "Occasionally — sales has to clarify on most deals", points: 55, evidence: "moderate", flagIds: ["packaging.explainability-friction"] },
      { value: "c", label: "Frequently — confusion shows up chronically in support or renewal conversations", points: 30, evidence: "strong", flagIds: ["packaging.chronic-confusion"] },
      { value: "d", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["packaging.visibility-gap"] },
    ],
  },

  // PRICE METRIC
  {
    id: "metric.alignment", stage: "priceMetric",
    prompt: "Does your primary price metric (seat, usage, transaction, flat fee, etc.) scale with the value the customer actually receives?",
    options: [
      { value: "a", label: "Yes — validated alignment; value and price grow together", points: 90, evidence: "strong" },
      { value: "b", label: "Mostly, but some segments feel it's mismatched", points: 55, evidence: "moderate", flagIds: ["metric.partial-misalignment"] },
      { value: "c", label: "No — the metric is disconnected from delivered value", points: 25, evidence: "strong", flagIds: ["metric.misaligned"] },
      { value: "d", label: "Never formally assessed", points: 50, evidence: "unknown", flagIds: ["metric.visibility-gap"] },
    ],
  },
  {
    id: "metric.objections", stage: "priceMetric",
    prompt: "How often does the pricing metric itself (not the price level) generate objections or billing disputes?",
    options: [
      { value: "a", label: "Rarely", points: 85, evidence: "strong" },
      { value: "b", label: "Sometimes, typically from a specific segment or usage pattern", points: 55, evidence: "moderate", flagIds: ["metric.segment-friction"] },
      { value: "c", label: "Frequently — a recurring source of disputes and churn risk", points: 25, evidence: "strong", flagIds: ["metric.chronic-disputes"] },
      { value: "d", label: "Not tracked centrally", points: 50, evidence: "unknown", flagIds: ["metric.visibility-gap"] },
    ],
  },
  {
    id: "metric.reviewed", stage: "priceMetric",
    prompt: "Has the pricing metric itself ever been deliberately reconsidered, versus inherited unexamined from early days?",
    options: [
      { value: "a", label: "Yes, reviewed deliberately as the business model matured", points: 85, evidence: "strong" },
      { value: "b", label: "Reviewed once, a while ago", points: 55, evidence: "moderate", flagIds: ["metric.aging-review"] },
      { value: "c", label: "Never — still the metric chosen at founding, unexamined", points: 35, evidence: "strong", flagIds: ["metric.unexamined"] },
      { value: "d", label: "Not sure", points: 50, evidence: "unknown", flagIds: ["metric.visibility-gap"] },
    ],
  },

  // PRICE LEVEL
  {
    id: "level.method", stage: "priceLevel",
    prompt: "How was your current price level originally set?",
    options: [
      { value: "a", label: "Structured value-based research (willingness-to-pay study, conjoint, value modeling)", points: 90, evidence: "strong" },
      { value: "b", label: "Benchmarked against competitors, adjusted by judgment", points: 60, evidence: "moderate", flagIds: ["level.competitor-anchored"] },
      { value: "c", label: "Cost-plus or margin-target formula", points: 45, evidence: "strong", flagIds: ["level.cost-plus"] },
      { value: "d", label: "Founder or gut judgment, never methodically revisited", points: 30, evidence: "strong", flagIds: ["level.gut-set"] },
    ],
  },
  {
    id: "level.lastraise", stage: "priceLevel",
    prompt: "When was list price last increased?",
    options: [
      { value: "a", label: "Within the last 12 months, deliberately", points: 85, evidence: "strong" },
      { value: "b", label: "1-2 years ago", points: 55, evidence: "moderate", flagIds: ["level.aging-price"] },
      { value: "c", label: "More than 2 years ago", points: 30, evidence: "strong", flagIds: ["level.stale-price"] },
      { value: "d", label: "Price has never been raised", points: 20, evidence: "strong", flagIds: ["level.never-raised"] },
    ],
  },
  {
    id: "level.winrate", stage: "priceLevel",
    prompt: "What is your win rate on deals that close at or near full list price, with no material discount?",
    options: [
      { value: "a", label: "High — most full-price deals close; discounting is rarely needed to win", points: 90, evidence: "strong" },
      { value: "b", label: "Moderate — full-price deals close roughly half the time", points: 55, evidence: "moderate", flagIds: ["level.marginal-list-viability"] },
      { value: "c", label: "Low — full-price deals rarely close without a discount", points: 25, evidence: "strong", flagIds: ["level.list-price-not-viable"] },
      { value: "d", label: "Not tracked separately from discounted deals", points: 50, evidence: "unknown", flagIds: ["level.visibility-gap"] },
    ],
  },

  // DISCOUNTING
  {
    id: "disc.governance", stage: "discounting",
    prompt: "Is there a formal, enforced discount approval process with escalation thresholds?",
    options: [
      { value: "a", label: "Yes, defined thresholds, consistently enforced", points: 88, evidence: "strong" },
      { value: "b", label: "A policy exists on paper but is routinely bypassed", points: 35, evidence: "strong", flagIds: ["disc.unenforced-policy"] },
      { value: "c", label: "No formal process — discretion sits with individual reps", points: 25, evidence: "strong", flagIds: ["disc.no-governance"] },
      { value: "d", label: "Not sure how discounting is actually approved", points: 50, evidence: "unknown", flagIds: ["disc.visibility-gap"] },
    ],
  },
  {
    id: "disc.depth", stage: "discounting",
    prompt: "What is the average discount off list price across closed deals?",
    options: [
      { value: "a", label: "0-10%", points: 90, evidence: "strong" },
      { value: "b", label: "11-20%", points: 65, evidence: "strong", flagIds: ["disc.moderate-depth"] },
      { value: "c", label: "21-35%", points: 40, evidence: "strong", flagIds: ["disc.deep-average"] },
      { value: "d", label: "More than 35%", points: 20, evidence: "strong", flagIds: ["disc.severe-depth"] },
      { value: "e", label: "Not tracked at a company level", points: 50, evidence: "unknown", flagIds: ["disc.visibility-gap"] },
    ],
  },
  {
    id: "disc.frequency", stage: "discounting",
    prompt: "What share of closed deals include any discount at all off list?",
    options: [
      { value: "a", label: "Under 25% of deals", points: 85, evidence: "strong" },
      { value: "b", label: "25-50% of deals", points: 60, evidence: "moderate", flagIds: ["disc.frequent"] },
      { value: "c", label: "50-80% of deals", points: 40, evidence: "strong", flagIds: ["disc.majority-discounted"] },
      { value: "d", label: "Over 80% — discounting is effectively the default", points: 20, evidence: "strong", flagIds: ["disc.default-discounting"] },
      { value: "e", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["disc.visibility-gap"] },
    ],
  },

  // CONVERSION
  {
    id: "conv.winrate", stage: "conversion",
    prompt: "What is your proposal-to-close win rate?",
    options: [
      { value: "a", label: "Above 40%", points: 85, evidence: "strong" },
      { value: "b", label: "25-40%", points: 60, evidence: "moderate", flagIds: ["conv.midrange-winrate"] },
      { value: "c", label: "10-25%", points: 40, evidence: "strong", flagIds: ["conv.low-winrate"] },
      { value: "d", label: "Below 10%", points: 20, evidence: "strong", flagIds: ["conv.very-low-winrate"] },
      { value: "e", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["conv.visibility-gap"] },
    ],
  },
  {
    id: "conv.cycle", stage: "conversion",
    prompt: "How has sales cycle length trended over the last 12 months?",
    options: [
      { value: "a", label: "Stable or shortening", points: 80, evidence: "strong" },
      { value: "b", label: "Lengthening moderately", points: 50, evidence: "strong", flagIds: ["conv.lengthening-cycle"] },
      { value: "c", label: "Lengthening significantly, with repeated deal stalls", points: 25, evidence: "strong", flagIds: ["conv.stalling-cycle"] },
      { value: "d", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["conv.visibility-gap"] },
    ],
  },
  {
    id: "conv.stallreason", stage: "conversion",
    prompt: "What's the most common reason deals stall before closing?",
    options: [
      { value: "a", label: "Buyer timing/priority, not pricing", points: 80, evidence: "strong" },
      { value: "b", label: "Internal procurement or legal process friction", points: 55, evidence: "moderate", flagIds: ["conv.procurement-friction"] },
      { value: "c", label: "Unresolved price or budget objections", points: 30, evidence: "strong", flagIds: ["conv.price-objection-stalls"] },
      { value: "d", label: "Unclear / not tracked by sales", points: 50, evidence: "unknown", flagIds: ["conv.visibility-gap"] },
    ],
  },

  // EXPANSION
  {
    id: "exp.nrr", stage: "expansion",
    prompt: "What is your approximate net revenue retention (existing customer revenue growth, net of churn)?",
    options: [
      { value: "a", label: "Above 110%", points: 90, evidence: "strong" },
      { value: "b", label: "100-110%", points: 65, evidence: "moderate", flagIds: ["exp.flat-expansion"] },
      { value: "c", label: "90-100%", points: 40, evidence: "strong", flagIds: ["exp.net-contraction"] },
      { value: "d", label: "Below 90%", points: 20, evidence: "strong", flagIds: ["exp.severe-contraction"] },
      { value: "e", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["exp.visibility-gap"] },
    ],
  },
  {
    id: "exp.motion", stage: "expansion",
    prompt: "Is there a structured, repeatable path for customers to expand (seat growth, usage tiers, module upsell)?",
    options: [
      { value: "a", label: "Yes, systematized with clear triggers and ownership", points: 88, evidence: "strong" },
      { value: "b", label: "Informal — happens opportunistically when a rep notices", points: 45, evidence: "strong", flagIds: ["exp.ad-hoc-motion"] },
      { value: "c", label: "No structured path exists", points: 25, evidence: "strong", flagIds: ["exp.no-motion"] },
      { value: "d", label: "Not sure", points: 50, evidence: "unknown", flagIds: ["exp.visibility-gap"] },
    ],
  },
  {
    id: "exp.share", stage: "expansion",
    prompt: "What share of accounts expanded (grew spend) in the last 12 months?",
    options: [
      { value: "a", label: "Over 30% of accounts", points: 85, evidence: "strong" },
      { value: "b", label: "10-30%", points: 55, evidence: "moderate", flagIds: ["exp.limited-expansion"] },
      { value: "c", label: "Under 10%", points: 30, evidence: "strong", flagIds: ["exp.stagnant-base"] },
      { value: "d", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["exp.visibility-gap"] },
    ],
  },

  // RETENTION
  {
    id: "ret.renewal", stage: "retention",
    prompt: "How are renewal prices typically handled?",
    options: [
      { value: "a", label: "Systematic annual uplift tied to value/inflation, applied consistently", points: 88, evidence: "strong" },
      { value: "b", label: "Case-by-case judgment at each renewal", points: 50, evidence: "strong", flagIds: ["ret.discretionary-renewals"] },
      { value: "c", label: "Renewed flat at the same price by default", points: 45, evidence: "strong", flagIds: ["ret.flat-renewals"] },
      { value: "d", label: "Whatever it takes to avoid churn, including pricing below the prior term", points: 20, evidence: "strong", flagIds: ["ret.renewal-erosion"] },
    ],
  },
  {
    id: "ret.churn", stage: "retention",
    prompt: "What is your approximate gross (logo or revenue) churn rate?",
    options: [
      { value: "a", label: "Under 5% annually", points: 88, evidence: "strong" },
      { value: "b", label: "5-10%", points: 60, evidence: "moderate", flagIds: ["ret.moderate-churn"] },
      { value: "c", label: "10-20%", points: 35, evidence: "strong", flagIds: ["ret.elevated-churn"] },
      { value: "d", label: "Above 20%", points: 15, evidence: "strong", flagIds: ["ret.severe-churn"] },
      { value: "e", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["ret.visibility-gap"] },
    ],
  },
  {
    id: "ret.discountrenew", stage: "retention",
    prompt: "What share of renewals happen at a discount versus full list-equivalent value?",
    options: [
      { value: "a", label: "Under 10%", points: 85, evidence: "strong" },
      { value: "b", label: "10-30%", points: 55, evidence: "moderate", flagIds: ["ret.some-discounted-renewals"] },
      { value: "c", label: "30-60%", points: 35, evidence: "strong", flagIds: ["ret.majority-discounted-renewals"] },
      { value: "d", label: "Over 60%", points: 20, evidence: "strong", flagIds: ["ret.chronic-discounted-renewals"] },
      { value: "e", label: "Not tracked", points: 50, evidence: "unknown", flagIds: ["ret.visibility-gap"] },
    ],
  },

  // MARGIN
  {
    id: "margin.trend", stage: "margin",
    prompt: "How has gross margin trended over the last two years?",
    options: [
      { value: "a", label: "Stable or improving", points: 88, evidence: "strong" },
      { value: "b", label: "Slightly declining", points: 55, evidence: "strong", flagIds: ["margin.eroding"] },
      { value: "c", label: "Materially declining", points: 25, evidence: "strong", flagIds: ["margin.material-erosion"] },
      { value: "d", label: "Not tracked at a product/deal level", points: 50, evidence: "unknown", flagIds: ["margin.visibility-gap"] },
    ],
  },
  {
    id: "margin.incentives", stage: "margin",
    prompt: "Do sales incentives reward margin-healthy deals, or only closed revenue regardless of discount given?",
    options: [
      { value: "a", label: "Comp is explicitly weighted toward margin/net price, not just bookings", points: 88, evidence: "strong" },
      { value: "b", label: "Comp is on revenue only; discounting is effectively free to the rep", points: 30, evidence: "strong", flagIds: ["margin.misaligned-incentives"] },
      { value: "c", label: "Mixed or inconsistent across teams", points: 50, evidence: "moderate", flagIds: ["margin.inconsistent-incentives"] },
      { value: "d", label: "Not sure how comp plans treat discounting", points: 50, evidence: "unknown", flagIds: ["margin.visibility-gap"] },
    ],
  },
  {
    id: "margin.tracking", stage: "margin",
    prompt: "Are discounts tracked against margin impact, or only against list price?",
    options: [
      { value: "a", label: "Tracked against margin/unit economics impact, visible to leadership", points: 88, evidence: "strong" },
      { value: "b", label: "Only tracked against list price — margin impact isn't visible deal-by-deal", points: 40, evidence: "strong", flagIds: ["margin.list-only-tracking"] },
      { value: "c", label: "Not tracked in any structured way", points: 25, evidence: "strong", flagIds: ["margin.no-tracking"] },
      { value: "d", label: "Not sure", points: 50, evidence: "unknown", flagIds: ["margin.visibility-gap"] },
    ],
  },
];

export const BUSINESS_MODELS = [
  { value: "saas-subscription", label: "SaaS / Subscription" },
  { value: "usage-based", label: "Usage-based / Consumption" },
  { value: "services-contracts", label: "Services & Contracts" },
  { value: "product-transactional", label: "Product / Transactional" },
];
