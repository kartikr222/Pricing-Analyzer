import { NextResponse } from "next/server";
import { BUSINESS_MODELS, QUESTIONS } from "@/lib/pricing-analyzer/questions";
import { createAssessment } from "@/lib/pricing-analyzer/store";
import type { Answers, IntakeContext } from "@/lib/pricing-analyzer/types";

export const dynamic = "force-dynamic";

const VALID_MODELS = new Set(BUSINESS_MODELS.map((m) => m.value));

function validate(body: unknown): { context: IntakeContext; answers: Answers } | { error: string } {
  if (!body || typeof body !== "object") return { error: "Malformed request body." };
  const payload = body as Record<string, unknown>;
  const rawContext = payload.context;
  const rawAnswers = payload.answers;

  if (!rawContext || typeof rawContext !== "object") return { error: "Missing company context." };
  if (!rawAnswers || typeof rawAnswers !== "object") return { error: "Missing diagnostic answers." };

  const ctx = rawContext as Record<string, unknown>;
  const businessModel = typeof ctx.businessModel === "string" ? ctx.businessModel : "";
  if (!VALID_MODELS.has(businessModel)) return { error: "Please select a valid business model." };

  const organization = typeof ctx.organization === "string" && ctx.organization.trim() ? ctx.organization.trim().slice(0, 200) : undefined;
  const contactEmail = typeof ctx.contactEmail === "string" && ctx.contactEmail.trim() ? ctx.contactEmail.trim().slice(0, 200) : undefined;
  const currency = typeof ctx.currency === "string" && ctx.currency.trim() ? ctx.currency.trim().slice(0, 8) : "USD";

  let annualRevenue: number | undefined;
  if (ctx.annualRevenue !== undefined && ctx.annualRevenue !== null && ctx.annualRevenue !== "") {
    const parsed = Number(ctx.annualRevenue);
    if (!Number.isFinite(parsed) || parsed < 0) return { error: "Annual revenue must be a positive number." };
    annualRevenue = Math.round(parsed);
  }

  const answersInput = rawAnswers as Record<string, unknown>;
  const answers: Answers = {};

  for (const question of QUESTIONS) {
    const value = answersInput[question.id];
    if (typeof value !== "string" || !question.options.some((o) => o.value === value)) {
      return { error: `Missing or invalid answer for: "${question.prompt}"` };
    }
    answers[question.id] = value;
  }

  return {
    context: { organization, contactEmail, businessModel, annualRevenue, currency },
    answers,
  };
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const result = validate(body);
  if ("error" in result) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  try {
    const { id, report } = await createAssessment(result.context, result.answers);
    return NextResponse.json({ id, report }, { status: 201 });
  } catch (err) {
    console.error("pricing-analyzer submit failed", err);
    return NextResponse.json({ error: "Could not save the assessment. Please try again." }, { status: 500 });
  }
}
