import { NextResponse } from "next/server";
import { getAssessment } from "@/lib/pricing-analyzer/store";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const report = await getAssessment(id);
  if (!report) {
    return NextResponse.json({ error: "Assessment not found." }, { status: 404 });
  }
  return NextResponse.json({ report });
}
