import type { Metadata } from "next";
import type { ReactNode } from "react";
import { SiteHeader } from "@/components/site/Header";
import { SiteFooter } from "@/components/site/Footer";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kartik Clarity™ — Pricing Analyzer™ | Revenue Leak Detection",
  description:
    "Kartik Clarity™ Pricing Analyzer™ is a forensic pricing diagnostic that traces revenue leakage across Value, Buyer, Offer, Packaging, Price Metric, Price Level, Discounting, Conversion, Expansion, Retention, and Margin — with evidence-based findings, a deterministic score, and a separately-stated confidence rating.",
  metadataBase: new URL("https://kartikclarity.com"),
  openGraph: {
    title: "Kartik Clarity™ — Pricing Analyzer™",
    description: "Forensic pricing diagnostics. Think. Focus. Achieve.",
    images: ["/brand/logo-rectangle.jpeg"],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col bg-kc-paper text-kc-ink antialiased">
        <SiteHeader />
        <div className="flex-1">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
