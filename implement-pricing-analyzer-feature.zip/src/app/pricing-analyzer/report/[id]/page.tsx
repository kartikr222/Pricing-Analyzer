import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getAssessment } from "@/lib/pricing-analyzer/store";
import { BUSINESS_MODELS } from "@/lib/pricing-analyzer/questions";
import { ScoreLedger } from "@/components/pricing-analyzer/report/ScoreLedger";
import { PrintButton } from "@/components/pricing-analyzer/report/PrintButton";
import { ProblemClassBadge, SeverityBadge, EffortBadge } from "@/components/pricing-analyzer/report/Badges";

export const metadata: Metadata = {
  title: "Your Pricing Analyzer™ Report | Kartik Clarity™",
};

const CONFIDENCE_STYLE: Record<string, string> = {
  high: "border-kc-blue/40 bg-kc-blue/10 text-kc-blue",
  moderate: "border-kc-amber/40 bg-kc-amber/10 text-kc-amber",
  low: "border-kc-danger/40 bg-kc-danger/10 text-kc-danger",
};

export default async function ReportPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const report = await getAssessment(id);
  if (!report) notFound();

  const businessModelLabel = BUSINESS_MODELS.find((m) => m.value === report.context.businessModel)?.label ?? report.context.businessModel;
  const priorityActions = report.actions.slice(0, 6);
  const remainingActions = report.actions.slice(6);
  const currency = report.context.currency || "USD";

  return (
    <main className="bg-kc-paper pb-24">
      {/* ───────── Exhibit header ───────── */}
      <section className="kc-grain bg-kc-ink text-white">
        <div className="mx-auto max-w-5xl px-6 py-14">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-mist">
                Pricing Analyzer™ · Case File #{id.slice(0, 8)}
              </p>
              <h1 className="font-display mt-3 text-3xl font-semibold sm:text-4xl">
                {report.context.organization || "Confidential Diagnostic Report"}
              </h1>
              <p className="mt-2 text-sm text-white/60">
                {businessModelLabel} · Generated {new Date(report.generatedAt).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}
              </p>
            </div>
            <PrintButton />
          </div>

          <div className="mt-10 grid gap-8 lg:grid-cols-[1.3fr_1fr]">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-white/50">Composite diagnostic score</p>
                  <p className="font-mono mt-1 text-5xl font-semibold text-white">{report.compositeScore}<span className="text-xl text-white/40">/100</span></p>
                </div>
                <p className="font-display text-2xl font-semibold text-kc-mist">{report.scoreBand.label}</p>
              </div>
              <p className="mt-3 text-sm text-white/65">{report.scoreBand.description}</p>
              <div className="mt-6">
                <ScoreLedger score={report.compositeScore} />
              </div>
            </div>

            <div className={`rounded-2xl border p-6 ${CONFIDENCE_STYLE[report.confidence.level]}`}>
              <p className="text-xs font-semibold uppercase tracking-wide opacity-70">Diagnostic confidence — reported separately from score</p>
              <p className="font-display mt-2 text-xl font-semibold">{report.confidence.label}</p>
              <p className="mt-3 text-sm opacity-80">
                Evidence base: <span className="font-mono font-semibold">{report.confidence.evidenceScore}/100</span>.{" "}
                {report.confidence.unknownCount} of {report.confidence.totalQuestions} answers were marked
                &quot;not sure / not tracked.&quot;
              </p>
              <p className="mt-3 text-xs opacity-70">
                A score can only be as reliable as the evidence behind it. This rating is never blended into the
                composite score above — treat findings from low-evidence stages as directional.
              </p>
            </div>
          </div>

          <div className="mt-8 rounded-2xl border border-kc-cyan/25 bg-kc-cyan/5 p-6">
            <p className="text-xs font-semibold uppercase tracking-wide text-kc-mist">Diagnosis orientation</p>
            <p className="mt-2 text-sm leading-relaxed text-white/85">{report.diagnosisOrientation.narrative}</p>
          </div>
        </div>
      </section>

      {/* ───────── Stage exhibits ───────── */}
      <section className="mx-auto max-w-5xl px-6 py-14">
        <h2 className="font-display text-2xl font-semibold text-kc-ink">Stage-by-stage exhibit log</h2>
        <p className="mt-2 max-w-2xl text-sm text-kc-ink/60">
          Each stage is scored independently from your answers. A low score paired with a low
          evidence score means the finding is directional, not proven — instrument it before
          acting on it aggressively.
        </p>

        <div className="mt-8 space-y-4">
          {report.stages.map((stage) => (
            <details key={stage.stage} className="group rounded-2xl border border-kc-linen bg-white open:shadow-md">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-6 py-5">
                <div className="flex items-center gap-4">
                  <span className="font-mono w-14 flex-shrink-0 text-lg font-semibold text-kc-ink/30">{stage.score}</span>
                  <div>
                    <p className="font-display font-semibold text-kc-ink">{stage.label}</p>
                    <p className="text-xs text-kc-ink/50">Evidence {stage.evidenceScore}/100 · Weight {stage.weight}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <ProblemClassBadge value={stage.problemClass} />
                  <span className="text-kc-ink/30 transition group-open:rotate-180">▾</span>
                </div>
              </summary>
              <div className="border-t border-kc-linen px-6 py-5">
                <div className="mb-4 h-1.5 w-full overflow-hidden rounded-full bg-kc-linen">
                  <div className="h-full rounded-full bg-kc-blue" style={{ width: `${stage.score}%` }} />
                </div>
                {stage.flags.length === 0 ? (
                  <p className="text-sm text-kc-ink/60">No material findings triggered in this stage.</p>
                ) : (
                  <ul className="space-y-3">
                    {stage.flags.map((flag) => (
                      <li key={flag.id} className="border-l-2 border-kc-linen pl-4 text-sm text-kc-ink/75">
                        <div className="mb-1 flex flex-wrap items-center gap-2">
                          <SeverityBadge value={flag.severity} />
                          <ProblemClassBadge value={flag.class} />
                        </div>
                        {flag.finding}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </details>
          ))}
        </div>
      </section>

      {/* ───────── Leakage ledger ───────── */}
      <section className="border-y border-kc-linen bg-kc-linen/40">
        <div className="mx-auto max-w-5xl px-6 py-14">
          <h2 className="font-display text-2xl font-semibold text-kc-ink">Plausible revenue leakage exposure</h2>
          <p className="mt-2 max-w-2xl text-sm text-kc-ink/60">
            Heuristic exposure ranges, not audited figures. Each range reflects a documented
            pattern applied against {report.context.annualRevenue ? "your reported annual revenue" : "gross bookings — provide annual revenue for a dollar estimate"}.
            Ranges are intentionally wide to avoid false precision.
          </p>

          {report.leakage.length === 0 ? (
            <p className="mt-8 rounded-2xl border border-kc-linen bg-white p-6 text-sm text-kc-ink/60">
              No leakage-linked findings were triggered by your answers — no material exposure
              range applies at this time.
            </p>
          ) : (
            <div className="mt-8 divide-y divide-kc-linen overflow-hidden rounded-2xl border border-kc-linen bg-white">
              {report.leakage.map((item) => (
                <div key={item.flagId} className="flex flex-col gap-3 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="max-w-2xl">
                    <p className="text-sm font-semibold text-kc-ink">{item.title}</p>
                    <p className="mt-1 text-xs text-kc-ink/55">
                      {item.lowPct}–{item.highPct}% {item.note}
                    </p>
                  </div>
                  <div className="font-mono text-right text-sm font-semibold text-kc-blue">
                    {item.lowAmount !== undefined && item.highAmount !== undefined ? (
                      <>
                        {currency} {item.lowAmount.toLocaleString()} – {item.highAmount.toLocaleString()}
                      </>
                    ) : (
                      <>{item.lowPct}%–{item.highPct}% exposure</>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ───────── Action plan ───────── */}
      <section className="mx-auto max-w-5xl px-6 py-14">
        <h2 className="font-display text-2xl font-semibold text-kc-ink">Priority interventions</h2>
        <p className="mt-2 max-w-2xl text-sm text-kc-ink/60">
          Ranked by leverage (stage weight × severity) with effort shown alongside — not by
          severity alone. Start at the top unless a lower item is a quick, obvious win.
        </p>

        <ol className="mt-8 space-y-4">
          {priorityActions.map((action, i) => (
            <li key={action.flagId} className="rounded-2xl border border-kc-linen bg-white p-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs text-kc-steel">#{i + 1}</span>
                <SeverityBadge value={action.severity} />
                <ProblemClassBadge value={action.problemClass} />
                <EffortBadge value={action.effort} />
                {action.hasLeakage && (
                  <span className="rounded-full border border-kc-cyan/40 bg-kc-cyan/10 px-2.5 py-1 text-[11px] font-semibold text-kc-blue">
                    Leakage-linked
                  </span>
                )}
              </div>
              <p className="font-display mt-3 text-lg font-semibold text-kc-ink">{action.title}</p>
              <p className="mt-2 text-sm text-kc-ink/70">
                <span className="font-semibold text-kc-ink/85">Finding: </span>
                {action.finding}
              </p>
              <p className="mt-2 text-sm text-kc-ink/60">
                <span className="font-semibold text-kc-ink/85">Why this ranks here: </span>
                {action.rationale}
              </p>
            </li>
          ))}
        </ol>

        {remainingActions.length > 0 && (
          <details className="mt-8 rounded-2xl border border-kc-linen bg-white">
            <summary className="cursor-pointer px-6 py-4 text-sm font-semibold text-kc-ink/70">
              Additional findings log ({remainingActions.length})
            </summary>
            <ul className="space-y-3 border-t border-kc-linen px-6 py-5">
              {remainingActions.map((action) => (
                <li key={action.flagId} className="border-l-2 border-kc-linen pl-4 text-sm text-kc-ink/70">
                  <div className="mb-1 flex flex-wrap items-center gap-2">
                    <SeverityBadge value={action.severity} />
                    <ProblemClassBadge value={action.problemClass} />
                    <EffortBadge value={action.effort} />
                  </div>
                  <p className="font-medium text-kc-ink">{action.title}</p>
                  <p className="mt-1 text-kc-ink/60">{action.rationale}</p>
                </li>
              ))}
            </ul>
          </details>
        )}
      </section>

      <section className="mx-auto max-w-5xl px-6">
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-kc-linen bg-white p-6">
          <p className="max-w-xl text-xs text-kc-ink/50">
            This report is a structured, evidence-based diagnostic generated from self-reported
            answers. It is directional decision support, not an audited financial analysis or a
            substitute for professional advisory engagement.
          </p>
          <Link
            href="/pricing-analyzer"
            className="whitespace-nowrap rounded-full border border-kc-ink/15 px-5 py-2.5 text-xs font-semibold text-kc-ink/70 transition hover:border-kc-ink/40 hover:text-kc-ink"
          >
            Run another diagnostic
          </Link>
        </div>
      </section>
    </main>
  );
}
