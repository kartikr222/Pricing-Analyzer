import type { Metadata } from "next";
import { Wizard } from "@/components/pricing-analyzer/Wizard";

export const metadata: Metadata = {
  title: "Pricing Analyzer™ — Run the Diagnostic | Kartik Clarity™",
  description:
    "Answer evidence-based questions across eleven pricing stages to generate your forensic Pricing Analyzer™ report.",
};

export default function PricingAnalyzerPage() {
  return (
    <main className="bg-kc-paper">
      <div className="border-b border-kc-linen bg-kc-ink py-10 text-white">
        <div className="mx-auto max-w-4xl px-6">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-mist">
            Kartik Clarity™ · Revenue Leak Detection
          </p>
          <h1 className="font-display mt-2 text-3xl font-semibold sm:text-4xl">
            Pricing Analyzer™ Diagnostic
          </h1>
          <p className="mt-3 max-w-2xl text-white/70">
            33 evidence-based questions across 11 stages. Where you don&apos;t have hard data,
            say so — an honest &quot;not tracked&quot; answer produces a more useful report
            than a guess.
          </p>
        </div>
      </div>
      <Wizard />
    </main>
  );
}
