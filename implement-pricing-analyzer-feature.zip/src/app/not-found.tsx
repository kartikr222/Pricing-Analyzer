import Link from "next/link";
import Image from "next/image";

export default function NotFound() {
  return (
    <main className="grid min-h-[70vh] place-items-center bg-kc-paper px-6 py-20 text-center">
      <div className="max-w-md">
        <Image
          src="/brand/mark.svg"
          alt=""
          width={64}
          height={64}
          className="mx-auto h-14 w-14 rounded-2xl bg-kc-ink p-3"
        />
        <h1 className="font-display mt-6 text-2xl font-semibold text-kc-ink">
          This exhibit doesn&apos;t exist
        </h1>
        <p className="mt-2 text-sm text-kc-ink/60">
          The page or report you&apos;re looking for couldn&apos;t be found. It may have been
          removed, or the link may be incomplete.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex rounded-full bg-kc-ink px-6 py-3 text-sm font-semibold text-white transition hover:bg-kc-navy"
        >
          Back to Kartik Clarity™
        </Link>
      </div>
    </main>
  );
}
