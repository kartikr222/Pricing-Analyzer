import Image from "next/image";
import Link from "next/link";
import { STAGES } from "@/lib/pricing-analyzer/questions";

export default function HomePage() {
  return (
    <main>
      {/* ───────────────────────── HERO ───────────────────────── */}
      <section className="kc-grain relative overflow-hidden bg-kc-ink text-white">
        <div className="pointer-events-none absolute inset-0 opacity-25">
          <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-kc-blue blur-3xl" />
          <div className="absolute right-0 top-40 h-96 w-96 rounded-full bg-kc-cyan/30 blur-3xl" />
        </div>
        <div className="relative mx-auto grid max-w-6xl gap-12 px-6 py-20 sm:py-28 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-kc-cyan/40 bg-white/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-kc-mist">
              Revenue Leak Detection
            </p>
            <h1 className="font-display mt-6 text-[clamp(2.25rem,5vw,3.75rem)] font-semibold leading-[1.05] text-white">
              Pricing Analyzer<span className="align-super text-2xl">™</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-white/75">
              A forensic pricing diagnostic — not a survey, not a benchmark deck. We trace
              revenue leakage through eleven linked stages, from how value is proven to how
              margin is protected, and separate what your pricing <em>process</em> is doing
              wrong from what your price <em>number</em> is doing wrong.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link
                href="/pricing-analyzer"
                className="rounded-full bg-kc-cyan px-7 py-3.5 text-sm font-semibold text-kc-ink shadow-[0_18px_40px_rgba(143,227,239,0.25)] transition hover:brightness-105"
              >
                Run the Pricing Diagnostic
              </Link>
              <a
                href="#method"
                className="rounded-full border border-white/25 px-7 py-3.5 text-sm font-semibold text-white/85 transition hover:border-white/50 hover:text-white"
              >
                How the score works
              </a>
            </div>
            <p className="mt-5 text-xs text-white/45">
              Takes ~12 minutes. Produces a deterministic score, a separately-stated
              confidence rating, and a prioritized action log — not a generic report.
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-sm">
            <Image
              src="/brand/logo-circle.jpeg"
              alt="Kartik Clarity — Think. Focus. Achieve. Revenue Leak Detection."
              width={520}
              height={520}
              priority
              className="w-full drop-shadow-[0_30px_60px_rgba(11,27,58,0.55)]"
            />
          </div>
        </div>
      </section>

      {/* ───────────────────────── PROBLEM FRAMING ───────────────────────── */}
      <section className="border-b border-kc-linen bg-white">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <div className="grid gap-10 sm:grid-cols-3">
            <StatCard
              kicker="The mistake we see most"
              body="Teams treat every pricing complaint as a price-level problem and reach for a discount or a price change. Often the real fault sits upstream — in packaging, in discount governance, or in how value is proven — and a price change alone won't hold."
            />
            <StatCard
              kicker="Why this is different"
              body="Pricing Analyzer™ scores eleven linked stages independently, tags each finding as a system problem or a level problem, and shows its evidence — not a black-box grade."
            />
            <StatCard
              kicker="What you get"
              body="A deterministic score, a confidence rating reported separately from that score, plausible revenue-leakage ranges, and a prioritized, evidence-linked action list."
            />
          </div>
        </div>
      </section>

      {/* ───────────────────────── THE 11 STAGES ───────────────────────── */}
      <section id="diagnostics" className="bg-kc-paper">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-blue">
              The diagnostic chain
            </p>
            <h2 className="font-display mt-3 text-3xl font-semibold text-kc-ink sm:text-4xl">
              Value → Buyer → Offer → Packaging → Price Metric → Price Level →
              Discounting → Conversion → Expansion → Retention → Margin
            </h2>
            <p className="mt-4 text-kc-ink/70">
              Revenue leaks rarely announce themselves at the stage where they're actually
              caused. A churn problem is frequently a packaging problem wearing a retention
              costume. Each stage below is scored on its own evidence, then read together.
            </p>
          </div>

          <ol className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-kc-linen bg-kc-linen sm:grid-cols-2 lg:grid-cols-3">
            {STAGES.map((stage, i) => (
              <li key={stage.id} className="flex flex-col gap-2 bg-white p-6">
                <span className="font-mono text-xs text-kc-steel">
                  {String(i + 1).padStart(2, "0")} · weight {stage.weight}
                </span>
                <p className="font-display text-lg font-semibold text-kc-ink">{stage.label}</p>
                <p className="text-sm text-kc-ink/65">{stage.description}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ───────────────────────── METHOD ───────────────────────── */}
      <section id="method" className="border-y border-kc-linen bg-kc-ink text-white">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-mist">
            Diagnostic discipline
          </p>
          <h2 className="font-display mt-3 max-w-2xl text-3xl font-semibold sm:text-4xl">
            Score, confidence, and leakage are three separate numbers — on purpose.
          </h2>

          <div className="mt-12 grid gap-8 lg:grid-cols-3">
            <MethodCard
              index="01"
              title="Deterministic score"
              body="Every point is computed from a fixed rule applied to your own answers — never generated by a model. The same answers always produce the same score."
            />
            <MethodCard
              index="02"
              title="Confidence, stated separately"
              body="A high score built on 'not tracked' answers is not the same as a high score built on hard data. We report an evidence-based confidence rating alongside — never blended into — the score."
            />
            <MethodCard
              index="03"
              title="Leakage ranges, not fake precision"
              body="Where a finding has a plausible revenue impact, we show a heuristic exposure range with its basis stated in plain language — not a fabricated dollar figure dressed up as an audit."
            />
          </div>
        </div>
      </section>

      {/* ───────────────────────── FINAL CTA ───────────────────────── */}
      <section className="bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-6 py-20 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold text-kc-ink sm:text-3xl">
              Find out which of the eleven stages is actually costing you revenue.
            </h2>
            <p className="mt-2 max-w-xl text-kc-ink/65">
              No account required. Answers are stored only to generate your report link.
            </p>
          </div>
          <Link
            href="/pricing-analyzer"
            className="whitespace-nowrap rounded-full bg-kc-ink px-7 py-3.5 text-sm font-semibold text-white shadow-lg transition hover:bg-kc-navy"
          >
            Start the Pricing Analyzer™
          </Link>
        </div>
      </section>
    </main>
  );
}

function StatCard({ kicker, body }: { kicker: string; body: string }) {
  return (
    <div className="border-l-2 border-kc-cyan pl-5">
      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-kc-blue">{kicker}</p>
      <p className="mt-2 text-sm leading-relaxed text-kc-ink/75">{body}</p>
    </div>
  );
}

function MethodCard({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
      <span className="font-mono text-xs text-kc-cyan">{index}</span>
      <p className="font-display mt-3 text-xl font-semibold text-white">{title}</p>
      <p className="mt-2 text-sm leading-relaxed text-white/70">{body}</p>
    </div>
  );
}
