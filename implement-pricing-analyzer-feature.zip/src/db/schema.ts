import { pgTable, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";

// Pricing Analyzer™ — forensic pricing diagnostic submissions.
// `answers` stores the raw intake evidence exactly as submitted.
// `report` stores the deterministic engine output (scores, confidence,
// leakage exposure, prioritized actions) generated at submission time so
// results are reproducible and auditable from the report page/link.
export const pricingAssessments = pgTable("pricing_assessments", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  organization: text("organization"),
  contactEmail: text("contact_email"),
  businessModel: text("business_model").notNull(),
  annualRevenue: integer("annual_revenue"),
  currency: text("currency").notNull().default("USD"),
  answers: jsonb("answers").notNull(),
  report: jsonb("report").notNull(),
  compositeScore: integer("composite_score").notNull(),
  confidenceLevel: text("confidence_level").notNull(),
});

export type PricingAssessmentRow = typeof pricingAssessments.$inferSelect;
export type NewPricingAssessmentRow = typeof pricingAssessments.$inferInsert;
