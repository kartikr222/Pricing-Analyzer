"use client";

export function PrintButton() {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="kc-no-print rounded-full border border-white/25 px-5 py-2.5 text-xs font-semibold text-white/80 transition hover:border-white/50 hover:text-white"
    >
      Save / Print Report
    </button>
  );
}
