import type { Effort, ProblemClass, Severity } from "@/lib/pricing-analyzer/types";

const CLASS_STYLE: Record<ProblemClass | "healthy", { label: string; className: string }> = {
  system: { label: "System issue", className: "bg-kc-danger/10 text-kc-danger border-kc-danger/30" },
  level: { label: "Price-level issue", className: "bg-kc-amber/10 text-kc-amber border-kc-amber/30" },
  mixed: { label: "Mixed signal", className: "bg-kc-steel/10 text-kc-steel border-kc-steel/30" },
  healthy: { label: "No material issue", className: "bg-kc-blue/10 text-kc-blue border-kc-blue/30" },
};

export function ProblemClassBadge({ value }: { value: ProblemClass | "healthy" }) {
  const style = CLASS_STYLE[value];
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold ${style.className}`}>
      {style.label}
    </span>
  );
}

const SEVERITY_STYLE: Record<Severity, string> = {
  high: "bg-kc-danger text-white",
  medium: "bg-kc-amber text-white",
  low: "bg-kc-steel text-white",
};

export function SeverityBadge({ value }: { value: Severity }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide ${SEVERITY_STYLE[value]}`}>
      {value} severity
    </span>
  );
}

const EFFORT_LABEL: Record<Effort, string> = { low: "Low effort", medium: "Medium effort", high: "High effort" };

export function EffortBadge({ value }: { value: Effort }) {
  return (
    <span className="inline-flex items-center rounded-full border border-kc-linen px-2.5 py-1 text-[11px] font-semibold text-kc-ink/60">
      {EFFORT_LABEL[value]}
    </span>
  );
}
