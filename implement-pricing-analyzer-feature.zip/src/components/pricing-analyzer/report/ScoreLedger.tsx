const BANDS = [
  { label: "Fragile", from: 0, to: 40, color: "bg-kc-danger/70" },
  { label: "Leaking", from: 40, to: 60, color: "bg-kc-amber/70" },
  { label: "Stable", from: 60, to: 75, color: "bg-kc-steel/60" },
  { label: "Disciplined", from: 75, to: 100, color: "bg-kc-blue/80" },
];

export function ScoreLedger({ score }: { score: number }) {
  const clamped = Math.max(0, Math.min(100, score));
  return (
    <div>
      <div className="relative h-6 w-full overflow-hidden rounded-full border border-white/15 bg-white/5">
        <div className="flex h-full w-full">
          {BANDS.map((b) => (
            <div key={b.label} className={`h-full ${b.color}`} style={{ width: `${b.to - b.from}%` }} />
          ))}
        </div>
        <div
          className="absolute top-0 h-full w-[3px] -translate-x-1/2 bg-white shadow-[0_0_0_2px_rgba(11,27,58,0.9)]"
          style={{ left: `${clamped}%` }}
          aria-hidden
        />
      </div>
      <div className="mt-2 flex justify-between text-[11px] font-medium uppercase tracking-wide text-white/45">
        {BANDS.map((b) => (
          <span key={b.label}>{b.label}</span>
        ))}
      </div>
    </div>
  );
}
