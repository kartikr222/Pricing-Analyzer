"use client";

import { useMemo, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { BUSINESS_MODELS, QUESTIONS, STAGES } from "@/lib/pricing-analyzer/questions";
import type { StageId } from "@/lib/pricing-analyzer/types";

interface ContextState {
  organization: string;
  contactEmail: string;
  businessModel: string;
  annualRevenue: string;
  currency: string;
}

const INITIAL_CONTEXT: ContextState = {
  organization: "",
  contactEmail: "",
  businessModel: "",
  annualRevenue: "",
  currency: "USD",
};

type Step = { kind: "context" } | { kind: "stage"; stage: StageId } | { kind: "review" };

export function Wizard() {
  const router = useRouter();
  const [context, setContext] = useState<ContextState>(INITIAL_CONTEXT);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [stepIndex, setStepIndex] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const steps: Step[] = useMemo(
    () => [{ kind: "context" }, ...STAGES.map((s) => ({ kind: "stage" as const, stage: s.id })), { kind: "review" }],
    [],
  );

  const currentStep = steps[stepIndex];
  const totalSteps = steps.length;

  function stageQuestions(stage: StageId) {
    return QUESTIONS.filter((q) => q.stage === stage);
  }

  function isStageComplete(stage: StageId) {
    return stageQuestions(stage).every((q) => Boolean(answers[q.id]));
  }

  function canAdvance(): boolean {
    if (currentStep.kind === "context") {
      return context.businessModel.trim().length > 0;
    }
    if (currentStep.kind === "stage") {
      return isStageComplete(currentStep.stage);
    }
    return true;
  }

  function goNext() {
    setError(null);
    if (!canAdvance()) {
      setError(
        currentStep.kind === "context"
          ? "Select a business model to continue."
          : "Answer every question in this stage to continue — choose \"not sure / not tracked\" if you don't have data.",
      );
      return;
    }
    setStepIndex((i) => Math.min(i + 1, steps.length - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goBack() {
    setError(null);
    setStepIndex((i) => Math.max(i - 1, 0));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const answeredCount = QUESTIONS.filter((q) => Boolean(answers[q.id])).length;
  const allAnswered = answeredCount === QUESTIONS.length;

  async function handleSubmit() {
    if (!allAnswered || !context.businessModel) {
      setError("Please complete every stage before generating your report.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/pricing-analyzer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: {
            organization: context.organization || undefined,
            contactEmail: context.contactEmail || undefined,
            businessModel: context.businessModel,
            annualRevenue: context.annualRevenue ? Number(context.annualRevenue) : undefined,
            currency: context.currency,
          },
          answers,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error ?? "Something went wrong generating your report.");
      }
      router.push(`/pricing-analyzer/report/${data.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <ProgressBar stepIndex={stepIndex} totalSteps={totalSteps} answeredCount={answeredCount} totalQuestions={QUESTIONS.length} />

      <div className="mt-8 rounded-3xl border border-kc-linen bg-white p-6 shadow-[0_20px_50px_rgba(11,27,58,0.06)] sm:p-10">
        {currentStep.kind === "context" && (
          <ContextStep value={context} onChange={setContext} />
        )}

        {currentStep.kind === "stage" && (
          <StageStep
            stage={currentStep.stage}
            answers={answers}
            onAnswer={(qid, val) => setAnswers((a) => ({ ...a, [qid]: val }))}
          />
        )}

        {currentStep.kind === "review" && (
          <ReviewStep context={context} answered={answeredCount} total={QUESTIONS.length} allAnswered={allAnswered} />
        )}

        {error && (
          <p className="mt-6 rounded-xl border border-kc-danger/30 bg-kc-danger/5 px-4 py-3 text-sm text-kc-danger">
            {error}
          </p>
        )}

        <div className="mt-10 flex items-center justify-between border-t border-kc-linen pt-6">
          <button
            type="button"
            onClick={goBack}
            disabled={stepIndex === 0 || submitting}
            className="rounded-full px-5 py-2.5 text-sm font-semibold text-kc-ink/60 transition hover:text-kc-ink disabled:cursor-not-allowed disabled:opacity-30"
          >
            Back
          </button>

          {currentStep.kind === "review" ? (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={!allAnswered || submitting}
              className="rounded-full bg-kc-ink px-7 py-3 text-sm font-semibold text-white transition hover:bg-kc-navy disabled:cursor-not-allowed disabled:opacity-40"
            >
              {submitting ? "Generating report…" : "Generate Forensic Report"}
            </button>
          ) : (
            <button
              type="button"
              onClick={goNext}
              className="rounded-full bg-kc-blue px-7 py-3 text-sm font-semibold text-white transition hover:brightness-110"
            >
              Continue
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function ProgressBar({
  stepIndex,
  totalSteps,
  answeredCount,
  totalQuestions,
}: {
  stepIndex: number;
  totalSteps: number;
  answeredCount: number;
  totalQuestions: number;
}) {
  const pct = Math.round((stepIndex / (totalSteps - 1)) * 100);
  return (
    <div>
      <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-[0.14em] text-kc-steel">
        <span>
          Step {stepIndex + 1} of {totalSteps}
        </span>
        <span className="font-mono normal-case tracking-normal text-kc-ink/50">
          {answeredCount}/{totalQuestions} questions answered
        </span>
      </div>
      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-kc-linen">
        <div className="h-full rounded-full bg-kc-blue transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function ContextStep({
  value,
  onChange,
}: {
  value: ContextState;
  onChange: (v: ContextState) => void;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-kc-blue">Exhibit A</p>
      <h2 className="font-display mt-2 text-2xl font-semibold text-kc-ink">Company context</h2>
      <p className="mt-2 text-sm text-kc-ink/60">
        This calibrates the report. Annual revenue is optional — it's used only to translate
        leakage exposure from a percentage into an approximate dollar range.
      </p>

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        <Field label="Organization (optional)">
          <input
            type="text"
            value={value.organization}
            onChange={(e) => onChange({ ...value, organization: e.target.value })}
            placeholder="Acme, Inc."
            className="kc-input"
          />
        </Field>
        <Field label="Contact email (optional)">
          <input
            type="email"
            value={value.contactEmail}
            onChange={(e) => onChange({ ...value, contactEmail: e.target.value })}
            placeholder="you@company.com"
            className="kc-input"
          />
        </Field>
        <Field label="Business model" required>
          <select
            value={value.businessModel}
            onChange={(e) => onChange({ ...value, businessModel: e.target.value })}
            className="kc-input"
          >
            <option value="">Select one…</option>
            {BUSINESS_MODELS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-[1fr_auto] gap-3">
          <Field label="Annual revenue (optional)">
            <input
              type="number"
              min={0}
              value={value.annualRevenue}
              onChange={(e) => onChange({ ...value, annualRevenue: e.target.value })}
              placeholder="e.g. 4200000"
              className="kc-input"
            />
          </Field>
          <Field label="Currency">
            <input
              type="text"
              value={value.currency}
              maxLength={3}
              onChange={(e) => onChange({ ...value, currency: e.target.value.toUpperCase() })}
              className="kc-input w-20 text-center uppercase"
            />
          </Field>
        </div>
      </div>
    </div>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-kc-ink/80">
        {label} {required && <span className="text-kc-danger">*</span>}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function StageStep({
  stage,
  answers,
  onAnswer,
}: {
  stage: StageId;
  answers: Record<string, string>;
  onAnswer: (questionId: string, value: string) => void;
}) {
  const stageMeta = STAGES.find((s) => s.id === stage)!;
  const questions = QUESTIONS.filter((q) => q.stage === stage);
  const stageNumber = STAGES.findIndex((s) => s.id === stage) + 1;

  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-kc-blue">
        Exhibit {String(stageNumber).padStart(2, "0")} · Weight {stageMeta.weight}
      </p>
      <h2 className="font-display mt-2 text-2xl font-semibold text-kc-ink">{stageMeta.label}</h2>
      <p className="mt-2 text-sm text-kc-ink/60">{stageMeta.description}</p>

      <div className="mt-8 space-y-8">
        {questions.map((q, idx) => (
          <fieldset key={q.id}>
            <legend className="text-sm font-semibold text-kc-ink">
              {idx + 1}. {q.prompt}
            </legend>
            <div className="mt-3 grid gap-2.5">
              {q.options.map((opt) => {
                const selected = answers[q.id] === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => onAnswer(q.id, opt.value)}
                    className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${
                      selected
                        ? "border-kc-blue bg-kc-blue/5 text-kc-ink"
                        : "border-kc-linen text-kc-ink/75 hover:border-kc-steel/50 hover:bg-kc-paper"
                    }`}
                  >
                    <span
                      className={`mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full border-2 ${
                        selected ? "border-kc-blue bg-kc-blue" : "border-kc-linen"
                      }`}
                    >
                      {selected && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                    </span>
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </fieldset>
        ))}
      </div>
    </div>
  );
}

function ReviewStep({
  context,
  answered,
  total,
  allAnswered,
}: {
  context: ContextState;
  answered: number;
  total: number;
  allAnswered: boolean;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-kc-blue">Final exhibit</p>
      <h2 className="font-display mt-2 text-2xl font-semibold text-kc-ink">Ready to generate your report</h2>
      <p className="mt-2 text-sm text-kc-ink/60">
        The diagnostic engine will compute your composite score, confidence rating, leakage
        exposure, and prioritized action plan directly from the answers you provided —
        deterministically, with no fabricated figures.
      </p>

      <dl className="mt-8 grid gap-4 sm:grid-cols-2">
        <ReviewRow label="Organization" value={context.organization || "—"} />
        <ReviewRow label="Business model" value={BUSINESS_MODELS.find((m) => m.value === context.businessModel)?.label ?? "—"} />
        <ReviewRow
          label="Annual revenue"
          value={context.annualRevenue ? `${context.currency} ${Number(context.annualRevenue).toLocaleString()}` : "Not provided"}
        />
        <ReviewRow label="Questions answered" value={`${answered} / ${total}`} />
      </dl>

      {!allAnswered && (
        <p className="mt-6 rounded-xl border border-kc-amber/30 bg-kc-amber/5 px-4 py-3 text-sm text-kc-amber">
          {total - answered} question{total - answered === 1 ? "" : "s"} still need an answer.
          Use Back to complete every stage before generating the report.
        </p>
      )}
    </div>
  );
}

function ReviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-kc-linen bg-kc-paper px-4 py-3">
      <dt className="text-xs font-semibold uppercase tracking-wide text-kc-steel">{label}</dt>
      <dd className="mt-1 text-sm font-medium text-kc-ink">{value}</dd>
    </div>
  );
}
