import Link from "next/link";
import Image from "next/image";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-kc-ink/95 backdrop-blur supports-[backdrop-filter]:bg-kc-ink/80">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link href="/" className="flex items-center gap-3" aria-label="Kartik Clarity home">
          <Image
            src="/brand/logo-rectangle.jpeg"
            alt="Kartik Clarity — Think. Focus. Achieve."
            width={138}
            height={69}
            priority
            className="h-10 w-auto sm:h-11"
          />
        </Link>
        <nav className="hidden items-center gap-8 text-sm font-medium text-white/80 sm:flex">
          <Link href="/#diagnostics" className="transition hover:text-kc-cyan">
            Diagnostics
          </Link>
          <Link href="/#method" className="transition hover:text-kc-cyan">
            Method
          </Link>
          <Link
            href="/pricing-analyzer"
            className="rounded-full border border-kc-cyan/60 bg-kc-cyan/10 px-4 py-2 text-kc-mist transition hover:bg-kc-cyan/20"
          >
            Pricing Analyzer™
          </Link>
        </nav>
        <Link
          href="/pricing-analyzer"
          className="rounded-full border border-kc-cyan/60 bg-kc-cyan/10 px-3 py-1.5 text-xs font-semibold text-kc-mist sm:hidden"
        >
          Start
        </Link>
      </div>
    </header>
  );
}
