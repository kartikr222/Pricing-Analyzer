import Image from "next/image";
import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-kc-ink text-white/70">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-6 py-14 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-5">
          <Image
            src="/brand/logo-circle.jpeg"
            alt="Kartik Clarity mark"
            width={96}
            height={96}
            className="h-20 w-20 flex-shrink-0"
          />
          <div>
            <p className="font-display text-lg text-white">Kartik Clarity™</p>
            <p className="mt-1 max-w-xs text-sm text-white/60">
              Think. Focus. Achieve. Forensic revenue-leak detection for growth-stage
              companies who need evidence, not opinions.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-10 text-sm sm:flex sm:gap-16">
          <div>
            <p className="font-semibold text-white/90">Diagnostics</p>
            <ul className="mt-3 space-y-2 text-white/60">
              <li>
                <Link href="/pricing-analyzer" className="transition hover:text-kc-cyan">
                  Pricing Analyzer™
                </Link>
              </li>
              <li className="text-white/35">Churn Forensics™ — in development</li>
              <li className="text-white/35">Funnel Autopsy™ — in development</li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-white/90">Company</p>
            <ul className="mt-3 space-y-2 text-white/60">
              <li>
                <Link href="/#method" className="transition hover:text-kc-cyan">
                  Diagnostic method
                </Link>
              </li>
              <li>
                <a href="mailto:info.kartikclarity@gmail.com" className="transition hover:text-kc-cyan">
                  info.kartikclarity@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-6 py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Kartik Clarity™. Revenue Leak Detection. All findings are
        directional diagnostics, not audited financial statements.
      </div>
    </footer>
  );
}
